import {
  collection,
  addDoc,
  getDocs,
  doc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  where,
  limit,
  Timestamp,
} from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { db, storage } from "./firebase";
import type {
  Doctor,
  Appointment,
  NewsArticle,
  ContactMessage,
} from "./firebase-types";

// Collections
export const COLLECTIONS = {
  DOCTORS: "doctors",
  APPOINTMENTS: "appointments",
  NEWS: "news",
  CONTACTS: "contacts",
  ADMIN_USERS: "adminUsers",
} as const;

// Doctors Service
export const doctorsService = {
  async getAll(): Promise<Doctor[]> {
    const querySnapshot = await getDocs(
      query(collection(db, COLLECTIONS.DOCTORS), orderBy("name")),
    );
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate(),
    })) as Doctor[];
  },

  async getActive(): Promise<Doctor[]> {
    const querySnapshot = await getDocs(
      query(
        collection(db, COLLECTIONS.DOCTORS),
        where("status", "==", "active"),
        orderBy("name"),
      ),
    );
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate(),
    })) as Doctor[];
  },

  async add(
    doctor: Omit<Doctor, "id" | "createdAt" | "updatedAt">,
  ): Promise<string> {
    const now = Timestamp.now();
    const docRef = await addDoc(collection(db, COLLECTIONS.DOCTORS), {
      ...doctor,
      createdAt: now,
      updatedAt: now,
    });
    return docRef.id;
  },

  async update(id: string, updates: Partial<Doctor>): Promise<void> {
    const docRef = doc(db, COLLECTIONS.DOCTORS, id);
    await updateDoc(docRef, {
      ...updates,
      updatedAt: Timestamp.now(),
    });
  },

  async delete(id: string): Promise<void> {
    await deleteDoc(doc(db, COLLECTIONS.DOCTORS, id));
  },

  async uploadImage(file: File, doctorId: string): Promise<string> {
    const storageRef = ref(storage, `doctors/${doctorId}/${file.name}`);
    const snapshot = await uploadBytes(storageRef, file);
    return await getDownloadURL(snapshot.ref);
  },
};

// Appointments Service
export const appointmentsService = {
  async getAll(): Promise<Appointment[]> {
    const querySnapshot = await getDocs(
      query(
        collection(db, COLLECTIONS.APPOINTMENTS),
        orderBy("createdAt", "desc"),
      ),
    );
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate(),
    })) as Appointment[];
  },

  async getPending(): Promise<Appointment[]> {
    const querySnapshot = await getDocs(
      query(
        collection(db, COLLECTIONS.APPOINTMENTS),
        where("status", "==", "pending"),
        orderBy("createdAt", "desc"),
      ),
    );
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate(),
    })) as Appointment[];
  },

  async add(
    appointment: Omit<Appointment, "id" | "createdAt" | "updatedAt">,
  ): Promise<string> {
    const now = Timestamp.now();
    const docRef = await addDoc(collection(db, COLLECTIONS.APPOINTMENTS), {
      ...appointment,
      status: "pending",
      createdAt: now,
      updatedAt: now,
    });
    return docRef.id;
  },

  async updateStatus(id: string, status: Appointment["status"]): Promise<void> {
    const docRef = doc(db, COLLECTIONS.APPOINTMENTS, id);
    await updateDoc(docRef, {
      status,
      updatedAt: Timestamp.now(),
    });
  },

  async delete(id: string): Promise<void> {
    await deleteDoc(doc(db, COLLECTIONS.APPOINTMENTS, id));
  },
};

// News Service
export const newsService = {
  async getAll(): Promise<NewsArticle[]> {
    const querySnapshot = await getDocs(
      query(collection(db, COLLECTIONS.NEWS), orderBy("publishDate", "desc")),
    );
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      publishDate: doc.data().publishDate?.toDate(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate(),
    })) as NewsArticle[];
  },

  async getPublished(limitCount?: number): Promise<NewsArticle[]> {
    let q = query(
      collection(db, COLLECTIONS.NEWS),
      where("published", "==", true),
      orderBy("publishDate", "desc"),
    );

    if (limitCount) {
      q = query(q, limit(limitCount));
    }

    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      publishDate: doc.data().publishDate?.toDate(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate(),
    })) as NewsArticle[];
  },

  async getFeatured(limitCount: number = 3): Promise<NewsArticle[]> {
    const querySnapshot = await getDocs(
      query(
        collection(db, COLLECTIONS.NEWS),
        where("featured", "==", true),
        where("published", "==", true),
        orderBy("publishDate", "desc"),
        limit(limitCount),
      ),
    );
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      publishDate: doc.data().publishDate?.toDate(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate(),
    })) as NewsArticle[];
  },

  async add(
    article: Omit<NewsArticle, "id" | "createdAt" | "updatedAt">,
  ): Promise<string> {
    const now = Timestamp.now();
    const docRef = await addDoc(collection(db, COLLECTIONS.NEWS), {
      ...article,
      publishDate: Timestamp.fromDate(article.publishDate),
      createdAt: now,
      updatedAt: now,
    });
    return docRef.id;
  },

  async update(id: string, updates: Partial<NewsArticle>): Promise<void> {
    const docRef = doc(db, COLLECTIONS.NEWS, id);
    const updateData: any = {
      ...updates,
      updatedAt: Timestamp.now(),
    };

    if (updates.publishDate) {
      updateData.publishDate = Timestamp.fromDate(updates.publishDate);
    }

    await updateDoc(docRef, updateData);
  },

  async delete(id: string): Promise<void> {
    await deleteDoc(doc(db, COLLECTIONS.NEWS, id));
  },

  async uploadImage(file: File, articleId: string): Promise<string> {
    const storageRef = ref(storage, `news/${articleId}/${file.name}`);
    const snapshot = await uploadBytes(storageRef, file);
    return await getDownloadURL(snapshot.ref);
  },
};

// Contact Messages Service
export const contactsService = {
  async getAll(): Promise<ContactMessage[]> {
    const querySnapshot = await getDocs(
      query(collection(db, COLLECTIONS.CONTACTS), orderBy("createdAt", "desc")),
    );
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate(),
    })) as ContactMessage[];
  },

  async getUnread(): Promise<ContactMessage[]> {
    const querySnapshot = await getDocs(
      query(
        collection(db, COLLECTIONS.CONTACTS),
        where("status", "==", "unread"),
        orderBy("createdAt", "desc"),
      ),
    );
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate(),
    })) as ContactMessage[];
  },

  async add(
    message: Omit<ContactMessage, "id" | "status" | "createdAt" | "updatedAt">,
  ): Promise<string> {
    const now = Timestamp.now();
    const docRef = await addDoc(collection(db, COLLECTIONS.CONTACTS), {
      ...message,
      status: "unread",
      createdAt: now,
      updatedAt: now,
    });
    return docRef.id;
  },

  async updateStatus(
    id: string,
    status: ContactMessage["status"],
  ): Promise<void> {
    const docRef = doc(db, COLLECTIONS.CONTACTS, id);
    await updateDoc(docRef, {
      status,
      updatedAt: Timestamp.now(),
    });
  },

  async delete(id: string): Promise<void> {
    await deleteDoc(doc(db, COLLECTIONS.CONTACTS, id));
  },
};

// Utility function to initialize default data
export const initializeDefaultData = async (): Promise<void> => {
  // Check if data already exists
  const doctorsSnapshot = await getDocs(collection(db, COLLECTIONS.DOCTORS));
  if (!doctorsSnapshot.empty) {
    return; // Data already exists
  }

  // Add default doctors
  const defaultDoctors = [
    {
      name: "Dr. Sarah Ahmed",
      specialty: "Interventional Cardiologist",
      experience: "15 years",
      education: "MD, Harvard Medical School",
      certifications: [
        "Board Certified Cardiologist",
        "Interventional Cardiology Fellowship",
      ],
      specialties: [
        "Angioplasty",
        "Cardiac Catheterization",
        "Stent Placement",
      ],
      bio: "Dr. Sarah Ahmed is a leading interventional cardiologist with over 15 years of experience in treating complex cardiovascular conditions.",
      image: "/placeholder.svg",
      email: "sarah.ahmed@heartcare.com",
      phone: "+213 555 001 001",
      rating: 4.9,
      patientsServed: 1200,
      status: "active" as const,
    },
    {
      name: "Dr. Mohamed Benali",
      specialty: "Electrophysiologist",
      experience: "12 years",
      education: "MD, University of Algiers",
      certifications: ["Cardiac Electrophysiology", "Arrhythmia Management"],
      specialties: [
        "Pacemaker Implantation",
        "Ablation Therapy",
        "Heart Rhythm Disorders",
      ],
      bio: "Dr. Mohamed Benali is an expert in cardiac electrophysiology, specializing in the diagnosis and treatment of heart rhythm disorders.",
      image: "/placeholder.svg",
      email: "mohamed.benali@heartcare.com",
      phone: "+213 555 002 002",
      rating: 4.8,
      patientsServed: 950,
      status: "active" as const,
    },
    {
      name: "Dr. Amina Khelifi",
      specialty: "Pediatric Cardiologist",
      experience: "10 years",
      education: "MD, University of Paris",
      certifications: ["Pediatric Cardiology", "Congenital Heart Disease"],
      specialties: [
        "Congenital Heart Defects",
        "Pediatric Echocardiography",
        "Heart Murmurs",
      ],
      bio: "Dr. Amina Khelifi specializes in pediatric cardiology, providing compassionate care for children with heart conditions.",
      image: "/placeholder.svg",
      email: "amina.khelifi@heartcare.com",
      phone: "+213 555 003 003",
      rating: 4.9,
      patientsServed: 800,
      status: "active" as const,
    },
  ];

  for (const doctor of defaultDoctors) {
    await doctorsService.add(doctor);
  }

  console.log("Default data initialized successfully");
};
