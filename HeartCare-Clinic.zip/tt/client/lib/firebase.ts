import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyBidw_rjVhdlTTb_OIgEGjLFXQuLM240WU",
  authDomain: "heartcare-clinic.firebaseapp.com",
  projectId: "heartcare-clinic",
  storageBucket: "heartcare-clinic.firebasestorage.app",
  messagingSenderId: "51049837074",
  appId: "1:51049837074:web:ad191d7b48f0037491decb",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
export const db = getFirestore(app);
export const storage = getStorage(app);
export const auth = getAuth(app);

export default app;
