export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  experience: string;
  education: string;
  certifications: string[];
  specialties: string[];
  bio: string;
  image: string;
  email: string;
  phone: string;
  rating: number;
  patientsServed: number;
  status: "active" | "inactive";
  createdAt: Date;
  updatedAt: Date;
}

export interface Appointment {
  id: string;
  doctorId: string;
  doctorName: string;
  patientName: string;
  phone: string;
  email?: string;
  date: string;
  time: string;
  reason?: string;
  status: "pending" | "confirmed" | "cancelled" | "completed";
  createdAt: Date;
  updatedAt: Date;
}

export interface NewsArticle {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  image: string;
  author: string;
  category: "research" | "technology" | "prevention" | "clinic-updates";
  tags: string[];
  publishDate: Date;
  readTime: string;
  featured: boolean;
  published: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  phone?: string;
  subject: string;
  message: string;
  status: "unread" | "read" | "replied";
  createdAt: Date;
  updatedAt: Date;
}

export interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: "admin" | "staff";
  createdAt: Date;
  lastLogin: Date;
}
