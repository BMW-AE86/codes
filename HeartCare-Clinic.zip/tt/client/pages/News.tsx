import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import Navigation from "@/components/Navigation";
import {
  Newspaper,
  Calendar,
  ArrowRight,
  Search,
  Heart,
  Activity,
  Stethoscope,
  Users,
} from "lucide-react";

export default function News() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const categories = [
    "all",
    "research",
    "technology",
    "prevention",
    "clinic-updates",
  ];

  const articles = [
    {
      id: 1,
      title:
        "New Advanced Cardiac Imaging Technology Arrives at HeartCare Clinic",
      excerpt:
        "We've introduced state-of-the-art 3D cardiac imaging equipment that provides unprecedented detail in diagnosing heart conditions, allowing for more precise treatments and better patient outcomes.",
      content: `HeartCare Clinic is proud to announce the installation of our new advanced cardiac imaging system, featuring the latest in 3D echocardiography and cardiac MRI technology. This cutting-edge equipment allows our cardiologists to visualize the heart in unprecedented detail, leading to more accurate diagnoses and personalized treatment plans.

      The new system offers several advantages over traditional imaging methods:
      • Higher resolution images for better diagnostic accuracy
      • Real-time 3D visualization of heart structures
      • Reduced scan times for improved patient comfort
      • Enhanced ability to detect early-stage heart disease

      Dr. Sarah Ahmed, our lead interventional cardiologist, commented: "This technology represents a significant advancement in our ability to provide precise, personalized cardiac care. We can now detect conditions earlier and plan treatments with greater accuracy than ever before."

            The imaging system is now available for all patients and is covered by most insurance plans. To schedule an imaging appointment, please contact our office at +213 557 921 145.`,
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2F4ad057a006b043899be532f43ec41bed",
      date: "December 15, 2024",
      author: "Dr. Sarah Ahmed",
      category: "technology",
      readTime: "3 min read",
      tags: ["Technology", "Imaging", "Diagnosis"],
    },
    {
      id: 2,
      title:
        "Heart Health Awareness Month: Free Screenings Available Throughout December",
      excerpt:
        "Join us for free heart health screenings and educational sessions throughout December. Our comprehensive program includes cholesterol testing, blood pressure checks, and consultations with our specialists.",
      content: `December is Heart Health Awareness Month, and HeartCare Clinic is offering complimentary heart health screenings to the community. These screenings are designed to help identify potential cardiovascular risk factors early, when they're most treatable.

      Our free screening program includes:
      • Blood pressure measurement
      • Cholesterol level testing
      • BMI calculation and assessment
      • Basic EKG reading
      • Consultation with a cardiac nurse
      • Educational materials on heart-healthy living

      The screenings will be held every Saturday in December from 9:00 AM to 2:00 PM at our clinic. No appointment is necessary, but we recommend arriving early as spaces are limited.

      Dr. Fatima Zohra, our preventive cardiologist, explains: "Early detection is key to preventing heart disease. These screenings can help identify risk factors before they become serious problems, allowing us to implement preventive measures that can significantly improve long-term heart health."

            Educational sessions on topics such as heart-healthy nutrition, exercise for cardiovascular health, and stress management will also be available. All sessions are free and open to the public.`,
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2F24263b36a8be4634ad20e06158e2d1d7",
      date: "December 10, 2024",
      author: "Dr. Fatima Zohra",
      category: "prevention",
      readTime: "4 min read",
      tags: ["Prevention", "Screening", "Community Health"],
    },
    {
      id: 3,
      title:
        "Telemedicine Services Now Available: Virtual Consultations from Home",
      excerpt:
        "Schedule virtual consultations with our specialists from the comfort of your home. Our new telemedicine platform offers secure, convenient access to expert cardiac care.",
      content: `HeartCare Clinic is pleased to announce the launch of our comprehensive telemedicine program, providing patients with convenient access to our cardiac specialists through secure video consultations.

      Our telemedicine services include:
      • Follow-up consultations for existing patients
      • Medication management reviews
      • Lifestyle counseling and education
      • Pre-surgical consultations
      • Second opinion consultations
      • Heart rhythm monitoring device reviews

      The platform features:
      • HIPAA-compliant secure video calls
      • Digital prescription management
      • Electronic health record integration
      • Secure messaging with healthcare providers
      • Appointment scheduling and reminders

      Dr. Omar Benaissa, our heart failure specialist, notes: "Telemedicine allows us to maintain continuity of care while providing greater convenience for our patients. This is particularly beneficial for follow-up visits and ongoing management of chronic conditions."

            To schedule a telemedicine appointment, patients can call our office or use our online booking system. Virtual consultations are covered by most insurance plans and offer the same quality of care as in-person visits for appropriate conditions.`,
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2Fde873c46d29b4480afe810c4a5736129",
      date: "December 5, 2024",
      author: "Dr. Omar Benaissa",
      category: "clinic-updates",
      readTime: "3 min read",
      tags: ["Telemedicine", "Technology", "Patient Care"],
    },
    {
      id: 4,
      title: "Breakthrough Research: New Treatment for Heart Rhythm Disorders",
      excerpt:
        "Recent clinical trials show promising results for a new minimally invasive treatment for atrial fibrillation, offering hope for patients with irregular heart rhythms.",
      content: `A groundbreaking clinical trial has demonstrated the effectiveness of a new catheter ablation technique for treating atrial fibrillation, the most common heart rhythm disorder. The study, involving over 1,000 patients across multiple centers, showed a 95% success rate in eliminating irregular heart rhythms.

      Key findings from the research:
      • 95% success rate in eliminating atrial fibrillation
      • 50% reduction in procedure time compared to traditional methods
      • Faster recovery times for patients
      • Lower risk of complications
      • Improved long-term outcomes

      Dr. Mohamed Benali, our electrophysiologist and principal investigator in the study, explains: "This new technique represents a significant advancement in treating heart rhythm disorders. The precision and effectiveness of this approach means better outcomes for patients with fewer complications."

      The procedure uses advanced mapping technology to precisely target the areas of the heart causing irregular rhythms, allowing for more accurate treatment while preserving healthy heart tissue.

            HeartCare Clinic is among the first centers in Algeria to offer this innovative treatment. Patients interested in learning more about this option should consult with our electrophysiology team to determine if they are candidates for the procedure.`,
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2F193f25827a09435fa38d39afae93822a",
      date: "November 28, 2024",
      author: "Dr. Mohamed Benali",
      category: "research",
      readTime: "5 min read",
      tags: ["Research", "Treatment", "Arrhythmia"],
    },
    {
      id: 5,
      title: "Pediatric Cardiology: Caring for Young Hearts",
      excerpt:
        "Our pediatric cardiology program provides specialized care for children with congenital heart conditions. Learn about our comprehensive approach to pediatric heart health.",
      content: `Children's hearts require specialized care, and our pediatric cardiology program is designed to provide comprehensive treatment for young patients with congenital and acquired heart conditions.

      Our pediatric services include:
      • Diagnosis and treatment of congenital heart defects
      • Fetal echocardiography for expectant mothers
      • Non-invasive cardiac testing for children
      • Family counseling and education
      • Coordination with pediatric cardiac surgeons
      • Long-term follow-up care

      Dr. Amina Khelifi, our pediatric cardiologist, emphasizes: "Caring for children with heart conditions requires not only medical expertise but also a gentle, family-centered approach. We work closely with families to ensure the best possible outcomes for young patients."

      Common conditions we treat include:
      • Ventricular septal defects (holes in the heart)
      • Atrial septal defects
      • Patent ductus arteriosus
      • Heart murmurs
      • Arrhythmias in children
      • Kawasaki disease

            Our child-friendly environment includes specially designed examination rooms, age-appropriate educational materials, and a team trained in pediatric care. We also offer support services for families, including counseling and connection with other families facing similar challenges.`,
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2F21fd1c3c1eb5439dbffd31e985a251d5",
      date: "November 22, 2024",
      author: "Dr. Amina Khelifi",
      category: "clinic-updates",
      readTime: "4 min read",
      tags: ["Pediatric Care", "Congenital Heart Disease", "Family Care"],
    },
    {
      id: 6,
      title: "The Importance of Regular Cardiac Check-ups",
      excerpt:
        "Regular cardiac screenings can detect heart disease early, when it's most treatable. Learn when and why you should schedule routine heart health evaluations.",
      content: `Heart disease remains the leading cause of death globally, but many cases can be prevented or managed effectively with early detection and proper care. Regular cardiac check-ups are essential for maintaining heart health and catching potential problems before they become serious.

      Who should have regular cardiac check-ups?
      • Adults over 40 years old
      • People with family history of heart disease
      • Those with diabetes, high blood pressure, or high cholesterol
      • Smokers or former smokers
      • Individuals with sedentary lifestyles
      • People experiencing chest pain, shortness of breath, or palpitations

      What to expect during a cardiac check-up:
      • Medical history review
      • Physical examination
      • Blood pressure measurement
      • Cholesterol and blood sugar testing
      • Electrocardiogram (EKG)
      • Echocardiogram if indicated
      • Discussion of risk factors and lifestyle modifications

      Dr. Fatima Zohra, our preventive cardiologist, advises: "Prevention is always better than treatment. Regular check-ups allow us to identify risk factors early and implement strategies to prevent heart disease before it develops."

            The frequency of cardiac check-ups depends on individual risk factors, but generally, adults should have a cardiovascular assessment every 1-2 years after age 40, or more frequently if risk factors are present.`,
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2F62e02a74808a4b14a8d13e338ae9ba77",
      date: "November 15, 2024",
      author: "Dr. Fatima Zohra",
      category: "prevention",
      readTime: "3 min read",
      tags: ["Prevention", "Check-ups", "Early Detection"],
    },
  ];

  const filteredArticles = articles.filter((article) => {
    const matchesSearch =
      article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      article.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory =
      selectedCategory === "all" || article.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const [expandedArticle, setExpandedArticle] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-accent/10 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto">
            <div className="bg-primary p-4 rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center">
              <Newspaper className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
              Health News & <span className="text-primary">Updates</span>
            </h1>
            <p className="text-xl text-muted-foreground">
              Stay informed about the latest developments in cardiac care,
              research breakthroughs, and clinic updates.
            </p>
          </div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="py-8 border-b">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search articles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={
                    selectedCategory === category ? "default" : "outline"
                  }
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className="capitalize"
                >
                  {category.replace("-", " ")}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Articles */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid gap-8 max-w-4xl mx-auto">
            {filteredArticles.map((article) => (
              <Card
                key={article.id}
                className="overflow-hidden hover:shadow-lg transition-shadow"
              >
                <div className="grid lg:grid-cols-4 gap-0">
                  {/* Article Image */}
                  <div className="lg:col-span-1">
                    <img
                      src={article.image}
                      alt={article.title}
                      className="w-full h-48 lg:h-full object-cover"
                    />
                  </div>

                  {/* Article Content */}
                  <div className="lg:col-span-3">
                    <CardHeader>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                          <Calendar className="h-4 w-4" />
                          <span>{article.date}</span>
                          <span>•</span>
                          <span>{article.readTime}</span>
                          <span>•</span>
                          <span>By {article.author}</span>
                        </div>
                        <Badge variant="secondary" className="capitalize">
                          {article.category.replace("-", " ")}
                        </Badge>
                      </div>
                      <CardTitle className="text-xl leading-tight hover:text-primary cursor-pointer">
                        {article.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-base mb-4">
                        {expandedArticle === article.id ? (
                          <div className="prose prose-sm max-w-none">
                            {article.content
                              .split("\n")
                              .map((paragraph, index) => (
                                <p key={index} className="mb-3">
                                  {paragraph}
                                </p>
                              ))}
                          </div>
                        ) : (
                          article.excerpt
                        )}
                      </CardDescription>

                      {/* Tags */}
                      <div className="flex flex-wrap gap-2 mb-4">
                        {article.tags.map((tag, index) => (
                          <Badge
                            key={index}
                            variant="outline"
                            className="text-xs"
                          >
                            {tag}
                          </Badge>
                        ))}
                      </div>

                      {/* Read More Button */}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() =>
                          setExpandedArticle(
                            expandedArticle === article.id ? null : article.id,
                          )
                        }
                        className="p-0 h-auto text-primary"
                      >
                        {expandedArticle === article.id
                          ? "Read Less"
                          : "Read More"}
                        <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </CardContent>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {filteredArticles.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">
                No articles found matching your search criteria.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-2xl mx-auto">
            <h2 className="text-3xl font-bold mb-4">
              Stay Updated with Heart Health News
            </h2>
            <p className="text-lg opacity-90 mb-8">
              Subscribe to our newsletter to receive the latest cardiac health
              updates, research findings, and clinic news directly in your
              inbox.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <Input
                placeholder="Enter your email"
                className="bg-white text-foreground"
              />
              <Button className="bg-accent hover:bg-accent/90 text-white">
                Subscribe
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
