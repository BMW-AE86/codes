import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import Navigation from "@/components/Navigation";
import { Calendar, Clock, User, Phone, CheckCircle, Heart } from "lucide-react";

export default function Appointment() {
  const [formData, setFormData] = useState({
    doctor: "",
    date: "",
    time: "",
    fullName: "",
    phone: "",
    email: "",
    reason: "",
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const doctors = [
    {
      id: "1",
      name: "Dr. Sarah Ahmed",
      specialty: "Interventional Cardiologist",
    },
    { id: "2", name: "Dr. Mohamed Benali", specialty: "Electrophysiologist" },
    { id: "3", name: "Dr. Amina Khelifi", specialty: "Pediatric Cardiologist" },
    { id: "4", name: "Dr. Karim Mansouri", specialty: "Cardiac Surgeon" },
    { id: "5", name: "Dr. Fatima Zohra", specialty: "Preventive Cardiologist" },
    {
      id: "6",
      name: "Dr. Omar Benaissa",
      specialty: "Heart Failure Specialist",
    },
  ];

  const timeSlots = [
    "09:00 AM",
    "09:30 AM",
    "10:00 AM",
    "10:30 AM",
    "11:00 AM",
    "11:30 AM",
    "12:00 PM",
    "12:30 PM",
    "01:00 PM",
    "01:30 PM",
    "02:00 PM",
    "02:30 PM",
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 2000);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-2xl mx-auto text-center">
            <div className="bg-accent/10 p-8 rounded-2xl border border-accent/20">
              <div className="bg-accent p-4 rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                <CheckCircle className="h-10 w-10 text-white" />
              </div>
              <h1 className="text-3xl font-bold text-foreground mb-4">
                Appointment Request Sent!
              </h1>
              <p className="text-lg text-muted-foreground mb-6">
                Thank you! Your appointment request has been sent successfully.
                We'll contact you soon to confirm your appointment details.
              </p>
              <div className="bg-background p-4 rounded-lg border mb-6">
                <h3 className="font-semibold text-foreground mb-2">
                  What's Next?
                </h3>
                <ul className="text-sm text-muted-foreground space-y-1 text-left">
                  <li>• Our team will call you within 24 hours</li>
                  <li>• We'll confirm your appointment time</li>
                  <li>• You'll receive a confirmation email</li>
                  <li>• Bring your insurance card and ID to the appointment</li>
                </ul>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button onClick={() => setIsSubmitted(false)}>
                  Book Another Appointment
                </Button>
                <Button
                  variant="outline"
                  onClick={() => (window.location.href = "/")}
                >
                  Return to Homepage
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-accent/10 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto">
            <div className="bg-primary p-4 rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center">
              <Calendar className="h-10 w-10 text-white" />
            </div>
            <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
              Book Your <span className="text-primary">Appointment</span>
            </h1>
            <p className="text-xl text-muted-foreground">
              Schedule a consultation with our expert cardiologists. We're here
              to provide you with the best cardiac care.
            </p>
          </div>
        </div>
      </section>

      {/* Appointment Form */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Form */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Heart className="h-6 w-6 text-primary" />
                      <span>Appointment Details</span>
                    </CardTitle>
                    <CardDescription>
                      Fill out the form below to request an appointment. All
                      fields are required.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-6">
                      {/* Doctor Selection */}
                      <div className="space-y-2">
                        <Label htmlFor="doctor">Select Doctor</Label>
                        <Select
                          onValueChange={(value) =>
                            handleInputChange("doctor", value)
                          }
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Choose a cardiologist" />
                          </SelectTrigger>
                          <SelectContent>
                            {doctors.map((doctor) => (
                              <SelectItem key={doctor.id} value={doctor.id}>
                                <div>
                                  <div className="font-medium">
                                    {doctor.name}
                                  </div>
                                  <div className="text-sm text-muted-foreground">
                                    {doctor.specialty}
                                  </div>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Date and Time */}
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="date">Preferred Date</Label>
                          <Input
                            id="date"
                            type="date"
                            value={formData.date}
                            onChange={(e) =>
                              handleInputChange("date", e.target.value)
                            }
                            min={new Date().toISOString().split("T")[0]}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="time">Preferred Time</Label>
                          <Select
                            onValueChange={(value) =>
                              handleInputChange("time", value)
                            }
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select time" />
                            </SelectTrigger>
                            <SelectContent>
                              {timeSlots.map((time) => (
                                <SelectItem key={time} value={time}>
                                  {time}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      {/* Personal Information */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">
                          Personal Information
                        </h3>
                        <div className="grid sm:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="fullName">Full Name</Label>
                            <Input
                              id="fullName"
                              value={formData.fullName}
                              onChange={(e) =>
                                handleInputChange("fullName", e.target.value)
                              }
                              placeholder="Enter your full name"
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="phone">Phone Number</Label>
                            <Input
                              id="phone"
                              type="tel"
                              value={formData.phone}
                              onChange={(e) =>
                                handleInputChange("phone", e.target.value)
                              }
                              placeholder="+213 XXX XXX XXX"
                              required
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email">
                            Email Address (Optional)
                          </Label>
                          <Input
                            id="email"
                            type="email"
                            value={formData.email}
                            onChange={(e) =>
                              handleInputChange("email", e.target.value)
                            }
                            placeholder="your.email@example.com"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="reason">
                            Reason for Visit (Optional)
                          </Label>
                          <Textarea
                            id="reason"
                            value={formData.reason}
                            onChange={(e) =>
                              handleInputChange("reason", e.target.value)
                            }
                            placeholder="Brief description of your symptoms or reason for consultation"
                            rows={3}
                          />
                        </div>
                      </div>

                      <Button
                        type="submit"
                        className="w-full"
                        size="lg"
                        disabled={
                          !formData.doctor ||
                          !formData.date ||
                          !formData.fullName ||
                          !formData.phone ||
                          isSubmitting
                        }
                      >
                        {isSubmitting ? "Submitting..." : "Request Appointment"}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                {/* Contact Info */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Phone className="h-5 w-5 text-primary" />
                      <span>Need Help?</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold">Call Us Directly</h4>
                      <p className="text-muted-foreground">+213 557 921 145</p>
                    </div>
                    <div>
                      <h4 className="font-semibold">Office Hours</h4>
                      <p className="text-muted-foreground">
                        Monday - Friday
                        <br />
                        9:00 AM - 3:00 PM
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold">Emergency</h4>
                      <p className="text-muted-foreground text-sm">
                        For urgent cardiac issues, call 911 or visit the nearest
                        emergency room.
                      </p>
                    </div>
                  </CardContent>
                </Card>

                {/* What to Expect */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Clock className="h-5 w-5 text-primary" />
                      <span>What to Expect</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li>• Comprehensive cardiac evaluation</li>
                      <li>• Discussion of symptoms and medical history</li>
                      <li>• Physical examination</li>
                      <li>• Diagnostic tests if needed</li>
                      <li>• Personalized treatment plan</li>
                      <li>• Follow-up recommendations</li>
                    </ul>
                  </CardContent>
                </Card>

                {/* Preparation */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <User className="h-5 w-5 text-primary" />
                      <span>Prepare for Your Visit</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      <li>• Bring your insurance card and ID</li>
                      <li>• List of current medications</li>
                      <li>• Previous medical records</li>
                      <li>• List of questions for your doctor</li>
                      <li>• Arrive 15 minutes early</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
