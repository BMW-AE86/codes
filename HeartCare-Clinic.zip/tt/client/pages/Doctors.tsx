import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Navigation from "@/components/Navigation";
import {
  AnimatedSection,
  StaggeredGrid,
  AnimatedText,
} from "@/components/ScrollAnimations";
import {
  Heart,
  Stethoscope,
  GraduationCap,
  Award,
  Calendar,
  Star,
  Users,
} from "lucide-react";

export default function Doctors() {
  const doctors = [
    {
      id: 1,
      name: "Dr. Sarah Ahmed",
      specialty: "Interventional Cardiologist",
      experience: "15 years",
      education: "MD, Harvard Medical School",
      certifications: [
        "Board Certified Cardiologist",
        "Interventional Cardiology Fellowship",
      ],
      specialties: [
        "Angioplasty",
        "Cardiac Catheterization",
        "Stent Placement",
      ],
      rating: 4.9,
      patientsServed: 1200,
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2Fd0ceac0fee2f4d858fa2d2d6f0c04e5f",
      bio: "Dr. Sarah Ahmed is a leading interventional cardiologist with over 15 years of experience in treating complex cardiovascular conditions. She specializes in minimally invasive procedures and has performed over 3000 successful interventions.",
    },
    {
      id: 2,
      name: "Dr. Mohamed Benali",
      specialty: "Electrophysiologist",
      experience: "12 years",
      education: "MD, University of Algiers",
      certifications: ["Cardiac Electrophysiology", "Arrhythmia Management"],
      specialties: [
        "Pacemaker Implantation",
        "Ablation Therapy",
        "Heart Rhythm Disorders",
      ],
      rating: 4.8,
      patientsServed: 950,
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2F5586d590a8f24ba69f0f2836f30a3b15",
      bio: "Dr. Mohamed Benali is an expert in cardiac electrophysiology, specializing in the diagnosis and treatment of heart rhythm disorders. He has extensive experience in device implantation and complex ablation procedures.",
    },
    {
      id: 3,
      name: "Dr. Amina Khelifi",
      specialty: "Pediatric Cardiologist",
      experience: "10 years",
      education: "MD, University of Paris",
      certifications: ["Pediatric Cardiology", "Congenital Heart Disease"],
      specialties: [
        "Congenital Heart Defects",
        "Pediatric Echocardiography",
        "Heart Murmurs",
      ],
      rating: 4.9,
      patientsServed: 800,
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2F748b583c84ae4e29b142fc070dc731a6",
      bio: "Dr. Amina Khelifi specializes in pediatric cardiology, providing compassionate care for children with heart conditions. She has particular expertise in congenital heart disease and non-invasive cardiac imaging.",
    },
    {
      id: 4,
      name: "Dr. Karim Mansouri",
      specialty: "Cardiac Surgeon",
      experience: "18 years",
      education: "MD, University of Tunis",
      certifications: ["Cardiac Surgery", "Thoracic Surgery"],
      specialties: ["Bypass Surgery", "Valve Replacement", "Heart Transplant"],
      rating: 4.9,
      patientsServed: 1500,
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2F6b6eb299411a473a834c334ac08d5403",
      bio: "Dr. Karim Mansouri is a highly skilled cardiac surgeon with expertise in complex heart surgeries. He has performed over 2000 successful cardiac procedures and is known for his precision and patient care.",
    },
    {
      id: 5,
      name: "Dr. Fatima Zohra",
      specialty: "Preventive Cardiologist",
      experience: "8 years",
      education: "MD, University of Constantine",
      certifications: ["Preventive Cardiology", "Lipidology"],
      specialties: [
        "Risk Assessment",
        "Lipid Management",
        "Lifestyle Medicine",
      ],
      rating: 4.7,
      patientsServed: 600,
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2F58f239dd842447e183cb713c9268d4da",
      bio: "Dr. Fatima Zohra focuses on preventive cardiology, helping patients reduce their risk of heart disease through lifestyle modifications and medical management. She is passionate about patient education and wellness.",
    },
    {
      id: 6,
      name: "Dr. Omar Benaissa",
      specialty: "Heart Failure Specialist",
      experience: "14 years",
      education: "MD, University of Oran",
      certifications: ["Heart Failure Management", "Advanced Heart Failure"],
      specialties: [
        "Heart Failure Treatment",
        "Cardiomyopathy",
        "Heart Transplant Evaluation",
      ],
      rating: 4.8,
      patientsServed: 1100,
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2F1998749d15ed44259aa4f44b64bf597a",
      bio: "Dr. Omar Benaissa is a heart failure specialist dedicated to improving the quality of life for patients with advanced heart conditions. He has extensive experience in managing complex heart failure cases.",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-accent/10 py-16">
        <div className="container mx-auto px-4">
          <AnimatedText className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
              Meet Our Expert{" "}
              <span className="text-primary">Cardiologists</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Our team of board-certified cardiologists brings decades of
              experience and specialized expertise to provide you with the
              highest quality cardiac care.
            </p>
            <div className="grid grid-cols-3 gap-6 max-w-md mx-auto">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">6</div>
                <div className="text-sm text-muted-foreground">Specialists</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">80+</div>
                <div className="text-sm text-muted-foreground">
                  Years Combined Experience
                </div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">5000+</div>
                <div className="text-sm text-muted-foreground">
                  Patients Treated
                </div>
              </div>
            </div>
          </AnimatedText>
        </div>
      </section>

      {/* Doctors Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <StaggeredGrid
            className="grid lg:grid-cols-2 gap-8"
            staggerDelay={200}
          >
            {doctors.map((doctor) => (
              <Card
                key={doctor.id}
                className="group hover:shadow-xl transition-all duration-300 overflow-hidden"
              >
                <CardContent className="p-0">
                  <div className="grid md:grid-cols-5 gap-0">
                    {/* Doctor Image */}
                    <div className="md:col-span-2 bg-secondary/30 p-6 flex items-center justify-center">
                      <div className="relative">
                        <img
                          src={doctor.image}
                          alt={doctor.name}
                          className="w-32 h-32 rounded-full object-cover border-4 border-primary/20 group-hover:border-primary/40 transition-colors"
                        />
                        <div className="absolute -bottom-2 -right-2 bg-primary text-white p-2 rounded-full">
                          <Stethoscope className="h-4 w-4" />
                        </div>
                      </div>
                    </div>

                    {/* Doctor Info */}
                    <div className="md:col-span-3 p-6">
                      <div className="space-y-4">
                        {/* Header */}
                        <div>
                          <h3 className="text-xl font-bold text-foreground mb-1">
                            {doctor.name}
                          </h3>
                          <p className="text-primary font-semibold mb-2">
                            {doctor.specialty}
                          </p>

                          {/* Stats */}
                          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                            <div className="flex items-center space-x-1">
                              <Star className="h-4 w-4 text-yellow-500 fill-current" />
                              <span>{doctor.rating}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Users className="h-4 w-4" />
                              <span>{doctor.patientsServed}+ patients</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <GraduationCap className="h-4 w-4" />
                              <span>{doctor.experience}</span>
                            </div>
                          </div>
                        </div>

                        {/* Specialties */}
                        <div>
                          <h4 className="text-sm font-semibold text-foreground mb-2">
                            Specialties:
                          </h4>
                          <div className="flex flex-wrap gap-1">
                            {doctor.specialties.map((specialty, index) => (
                              <Badge
                                key={index}
                                variant="secondary"
                                className="text-xs"
                              >
                                {specialty}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        {/* Bio */}
                        <p className="text-sm text-muted-foreground line-clamp-3">
                          {doctor.bio}
                        </p>

                        {/* Education & Certifications */}
                        <div className="space-y-2">
                          <div>
                            <h4 className="text-sm font-semibold text-foreground">
                              Education:
                            </h4>
                            <p className="text-sm text-muted-foreground">
                              {doctor.education}
                            </p>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex space-x-3 pt-2">
                          <Button asChild className="flex-1">
                            <Link to="/appointment">
                              <Calendar className="mr-2 h-4 w-4" />
                              Book Appointment
                            </Link>
                          </Button>
                          <Button variant="outline" size="sm">
                            View Profile
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </StaggeredGrid>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <AnimatedText>
            <h2 className="text-3xl font-bold mb-4">
              Ready to Schedule Your Consultation?
            </h2>
            <p className="text-lg opacity-90 mb-8 max-w-2xl mx-auto">
              Our experienced cardiologists are here to provide you with
              personalized, comprehensive cardiac care. Book your appointment
              today.
            </p>
          </AnimatedText>
          <AnimatedSection
            animation="fadeUp"
            delay={300}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Button
              asChild
              size="lg"
              className="bg-white text-primary hover:bg-white/90"
            >
              <Link to="/appointment">
                <Calendar className="mr-2 h-5 w-5" />
                Book Appointment
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="border-white text-white hover:bg-white/10"
            >
              <Link to="/contact">Contact Us</Link>
            </Button>
          </AnimatedSection>
        </div>
      </section>
    </div>
  );
}
