import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import Navigation from "@/components/Navigation";
import {
  AnimatedSection,
  StaggeredGrid,
  AnimatedCard,
  AnimatedText,
} from "@/components/ScrollAnimations";
import {
  Heart,
  Stethoscope,
  Activity,
  Users,
  Clock,
  MapPin,
  Phone,
  Mail,
  ArrowRight,
  Calendar,
  Award,
  Shield,
} from "lucide-react";

export default function Index() {
  const services = [
    {
      icon: <Heart className="h-8 w-8 text-primary" />,
      title: "ECG Testing",
      description:
        "Advanced electrocardiogram testing to monitor heart rhythm and detect irregularities.",
    },
    {
      icon: <Activity className="h-8 w-8 text-primary" />,
      title: "Stress Testing",
      description:
        "Comprehensive cardiac stress tests to evaluate heart function under physical activity.",
    },
    {
      icon: <Stethoscope className="h-8 w-8 text-primary" />,
      title: "Echocardiography",
      description:
        "Non-invasive ultrasound imaging to assess heart structure and function.",
    },
    {
      icon: <Shield className="h-8 w-8 text-primary" />,
      title: "Preventive Care",
      description:
        "Regular checkups and preventive measures to maintain optimal heart health.",
    },
  ];

  const doctors = [
    {
      name: "Dr. Sarah Ahmed",
      specialty: "Interventional Cardiologist",
      experience: "15 years",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2Fd0ceac0fee2f4d858fa2d2d6f0c04e5f",
    },
    {
      name: "Dr. Mohamed Benali",
      specialty: "Electrophysiologist",
      experience: "12 years",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2F5586d590a8f24ba69f0f2836f30a3b15",
    },
    {
      name: "Dr. Amina Khelifi",
      specialty: "Pediatric Cardiologist",
      experience: "10 years",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2F748b583c84ae4e29b142fc070dc731a6",
    },
  ];

  const news = [
    {
      title: "New Advanced Cardiac Imaging Technology",
      date: "December 15, 2024",
      excerpt:
        "We've introduced state-of-the-art cardiac imaging equipment to provide more accurate diagnoses.",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2F4ad057a006b043899be532f43ec41bed?format=webp",
    },
    {
      title: "Heart Health Awareness Month",
      date: "December 10, 2024",
      excerpt:
        "Join us for free heart health screenings and educational sessions throughout December.",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2F24263b36a8be4634ad20e06158e2d1d7",
    },
    {
      title: "Telemedicine Services Now Available",
      date: "December 5, 2024",
      excerpt:
        "Schedule virtual consultations with our specialists from the comfort of your home.",
      image:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2Fde873c46d29b4480afe810c4a5736129",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary/10 via-background to-accent/10 py-20 lg:py-32">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideRight" className="space-y-8">
              <AnimatedText className="space-y-4">
                <h1 className="text-4xl lg:text-6xl font-bold text-foreground leading-tight">
                  Your Heart's Health is Our{" "}
                  <span className="text-primary">Priority</span>
                </h1>
                <p className="text-xl text-muted-foreground max-w-lg">
                  Expert cardiac care with compassion. Our experienced team of
                  cardiologists provides comprehensive heart health services in
                  a state-of-the-art facility.
                </p>
              </AnimatedText>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  asChild
                  size="lg"
                  className="bg-primary hover:bg-primary/90"
                >
                  <Link to="/appointment">
                    <Calendar className="mr-2 h-5 w-5" />
                    Book Appointment
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link to="/contact">
                    <Phone className="mr-2 h-5 w-5" />
                    Call Now
                  </Link>
                </Button>
              </div>

              <div className="grid grid-cols-3 gap-6 pt-8">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">500+</div>
                  <div className="text-sm text-muted-foreground">
                    Patients Treated
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">15+</div>
                  <div className="text-sm text-muted-foreground">
                    Years Experience
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">24/7</div>
                  <div className="text-sm text-muted-foreground">
                    Emergency Care
                  </div>
                </div>
              </div>
            </AnimatedSection>

            <AnimatedSection animation="slideLeft" delay={300}>
              <div className="bg-white rounded-2xl shadow-2xl p-8 border">
                <img
                  src="https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2F19193b3c4cca4a8bb18d01b4939ec4e9"
                  alt="HeartCare Clinic"
                  className="w-full h-96 object-cover rounded-lg"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-accent text-white p-4 rounded-lg shadow-lg">
                <div className="flex items-center space-x-2">
                  <Award className="h-6 w-6" />
                  <div>
                    <div className="font-semibold">Certified Excellence</div>
                    <div className="text-sm opacity-90">
                      Joint Commission Accredited
                    </div>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideRight">
              <img
                src="https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2F86935fb1b4e642e0981807a008c5d20c"
                alt="About HeartCare Clinic"
                className="w-full h-96 object-cover rounded-lg shadow-lg"
              />
            </AnimatedSection>
            <AnimatedSection
              animation="slideLeft"
              delay={200}
              className="space-y-6"
            >
              <div>
                <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
                  About HeartCare Clinic
                </h2>
                <p className="text-lg text-muted-foreground">
                  Founded in 2009, HeartCare Clinic has been at the forefront of
                  cardiac care in Algeria. Our mission is to provide
                  exceptional, compassionate cardiovascular care using the
                  latest medical technologies and evidence-based treatments.
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Heart className="h-6 w-6 text-primary mt-1" />
                  <div>
                    <h3 className="font-semibold">Our Mission</h3>
                    <p className="text-muted-foreground">
                      To deliver world-class cardiac care with personalized
                      attention to each patient's unique needs.
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Users className="h-6 w-6 text-primary mt-1" />
                  <div>
                    <h3 className="font-semibold">Our Vision</h3>
                    <p className="text-muted-foreground">
                      To be the leading cardiac care center in Algeria,
                      recognized for excellence in patient outcomes.
                    </p>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <AnimatedText className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Our Services
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Comprehensive cardiac care services designed to keep your heart
              healthy at every stage of life.
            </p>
          </AnimatedText>

          <StaggeredGrid
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-6"
            staggerDelay={150}
          >
            {services.map((service, index) => (
              <Card
                key={index}
                className="group hover:shadow-lg transition-shadow"
              >
                <CardHeader className="text-center">
                  <div className="mx-auto mb-4 p-3 bg-primary/10 rounded-full w-fit group-hover:bg-primary/20 transition-colors">
                    {service.icon}
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center">
                    {service.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </StaggeredGrid>
        </div>
      </section>

      {/* Doctors Preview Section */}
      <section className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4">
          <AnimatedText className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Meet Our Experts
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our team of board-certified cardiologists brings decades of
              experience and expertise.
            </p>
          </AnimatedText>

          <StaggeredGrid
            className="grid md:grid-cols-3 gap-8"
            staggerDelay={200}
          >
            {doctors.map((doctor, index) => (
              <Card
                key={index}
                className="group hover:shadow-lg transition-shadow"
              >
                <CardContent className="p-6 text-center">
                  <div className="mb-4">
                    <img
                      src={doctor.image}
                      alt={doctor.name}
                      className="w-24 h-24 rounded-full mx-auto object-cover border-4 border-primary/20"
                    />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{doctor.name}</h3>
                  <p className="text-primary font-medium mb-1">
                    {doctor.specialty}
                  </p>
                  <p className="text-muted-foreground text-sm">
                    {doctor.experience} experience
                  </p>
                  <Button asChild variant="outline" className="mt-4" size="sm">
                    <Link to="/appointment">Book Appointment</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </StaggeredGrid>

          <div className="text-center mt-12">
            <Button asChild variant="outline" size="lg">
              <Link to="/doctors">
                Meet All Doctors
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* News Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <AnimatedText className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Latest News & Updates
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Stay informed about the latest developments in cardiac care and
              clinic updates.
            </p>
          </AnimatedText>

          <StaggeredGrid
            className="grid md:grid-cols-3 gap-8"
            staggerDelay={200}
          >
            {news.map((article, index) => (
              <Card
                key={index}
                className="group hover:shadow-lg transition-shadow overflow-hidden"
              >
                <div className="aspect-video overflow-hidden">
                  <img
                    src={article.image}
                    alt={article.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                </div>
                <CardHeader>
                  <CardDescription className="text-primary text-sm">
                    {article.date}
                  </CardDescription>
                  <CardTitle className="text-lg leading-tight">
                    {article.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-sm mb-4">
                    {article.excerpt}
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="p-0 h-auto text-primary"
                  >
                    Read More
                    <ArrowRight className="ml-1 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </StaggeredGrid>

          <AnimatedSection
            animation="fadeUp"
            delay={600}
            className="text-center mt-12"
          >
            <Button asChild variant="outline" size="lg">
              <Link to="/news">
                View All News
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </AnimatedSection>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideRight">
              <h2 className="text-3xl lg:text-4xl font-bold mb-6">
                Get in Touch
              </h2>
              <p className="text-lg opacity-90 mb-8">
                Ready to take the first step towards better heart health?
                Contact us today to schedule your consultation.
              </p>

              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5" />
                  <span>+213 557 921 145</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail className="h-5 w-5" />
                  <span>support@heartcareclinic.com</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Clock className="h-5 w-5" />
                  <span>Monday - Friday: 9:00 AM - 3:00 PM</span>
                </div>
                <div className="flex items-center space-x-3">
                  <MapPin className="h-5 w-5" />
                  <span>Algiers, Algeria</span>
                </div>
              </div>
            </AnimatedSection>

            <AnimatedSection
              animation="slideLeft"
              delay={300}
              className="bg-white/10 backdrop-blur-sm rounded-lg p-8"
            >
              <h3 className="text-xl font-semibold mb-6">Quick Contact</h3>
              <div className="space-y-4">
                <Button
                  asChild
                  className="w-full bg-white text-primary hover:bg-white/90"
                >
                  <Link to="/appointment">
                    <Calendar className="mr-2 h-5 w-5" />
                    Book Appointment
                  </Link>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  className="w-full border-white text-white hover:bg-white/10"
                >
                  <Link to="/contact" className="text-primary">
                    <Phone className="mr-2 h-5 w-5 text-primary" />
                    <span className="text-primary">Contact Us</span>
                  </Link>
                </Button>
              </div>

              <div className="mt-8 p-4 bg-white/10 rounded-lg">
                <h4 className="font-semibold mb-2">Emergency Care</h4>
                <p className="text-sm opacity-90">
                  For cardiac emergencies, please call 911 or visit your nearest
                  emergency room immediately.
                </p>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="bg-primary p-2 rounded-full">
                  <Heart className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">HeartCare</h3>
                  <p className="text-sm opacity-70">Clinic</p>
                </div>
              </div>
              <p className="text-sm opacity-70">
                Leading cardiac care center in Algeria, dedicated to providing
                exceptional heart health services.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <div className="space-y-2 text-sm">
                <Link
                  to="/doctors"
                  className="block opacity-70 hover:opacity-100"
                >
                  Our Doctors
                </Link>
                <Link
                  to="/appointment"
                  className="block opacity-70 hover:opacity-100"
                >
                  Book Appointment
                </Link>
                <Link to="/news" className="block opacity-70 hover:opacity-100">
                  News & Updates
                </Link>
                <Link
                  to="/contact"
                  className="block opacity-70 hover:opacity-100"
                >
                  Contact Us
                </Link>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <div className="space-y-2 text-sm opacity-70">
                <div>ECG Testing</div>
                <div>Stress Testing</div>
                <div>Echocardiography</div>
                <div>Preventive Care</div>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contact Info</h4>
              <div className="space-y-2 text-sm opacity-70">
                <div>+213 557 921 145</div>
                <div>support@heartcareclinic.com</div>
                <div>Mon-Fri: 9:00 AM - 3:00 PM</div>
                <div>Algiers, Algeria</div>
              </div>
            </div>
          </div>

          <div className="border-t border-white/20 mt-8 pt-8 text-center text-sm opacity-70">
            © 2024 HeartCare Clinic. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
