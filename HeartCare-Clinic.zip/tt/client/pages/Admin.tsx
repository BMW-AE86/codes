import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Navigation from "@/components/Navigation";
import {
  Calendar,
  Users,
  Settings,
  Search,
  Plus,
  Edit,
  Trash2,
  CheckCircle,
  X,
  Phone,
  Mail,
  Stethoscope,
  Clock,
  UserPlus,
} from "lucide-react";

export default function Admin() {
  const [appointments, setAppointments] = useState([
    {
      id: 1,
      patientName: "Ahmed Benali",
      doctorName: "Dr. Sarah Ahmed",
      date: "2024-12-20",
      time: "10:00 AM",
      phone: "+213 555 123 456",
      email: "ahmed.benali@email.com",
      reason: "Chest pain and shortness of breath",
      status: "pending",
    },
    {
      id: 2,
      patientName: "Fatima Khelifi",
      doctorName: "Dr. Mohamed Benali",
      date: "2024-12-21",
      time: "2:30 PM",
      phone: "+213 555 234 567",
      email: "fatima.k@email.com",
      reason: "Follow-up for arrhythmia",
      status: "confirmed",
    },
    {
      id: 3,
      patientName: "Omar Mansouri",
      doctorName: "Dr. Amina Khelifi",
      date: "2024-12-22",
      time: "9:00 AM",
      phone: "+213 555 345 678",
      email: "omar.m@email.com",
      reason: "Pediatric consultation for son",
      status: "pending",
    },
  ]);

  const [contacts, setContacts] = useState([
    {
      id: 1,
      name: "Leila Boudiaf",
      email: "leila.b@email.com",
      phone: "+213 555 456 789",
      subject: "Insurance Questions",
      message:
        "I have questions about my insurance coverage for cardiac procedures.",
      date: "2024-12-18",
      status: "unread",
    },
    {
      id: 2,
      name: "Karim Zeroual",
      email: "karim.z@email.com",
      phone: "+213 555 567 890",
      subject: "Second Opinion",
      message:
        "I would like to get a second opinion on my recent cardiac catheterization results.",
      date: "2024-12-17",
      status: "replied",
    },
  ]);

  const [doctors, setDoctors] = useState([
    {
      id: 1,
      name: "Dr. Sarah Ahmed",
      specialty: "Interventional Cardiologist",
      experience: "15 years",
      email: "sarah.ahmed@heartcare.com",
      phone: "+213 555 001 001",
      status: "active",
    },
    {
      id: 2,
      name: "Dr. Mohamed Benali",
      specialty: "Electrophysiologist",
      experience: "12 years",
      email: "mohamed.benali@heartcare.com",
      phone: "+213 555 002 002",
      status: "active",
    },
    {
      id: 3,
      name: "Dr. Amina Khelifi",
      specialty: "Pediatric Cardiologist",
      experience: "10 years",
      email: "amina.khelifi@heartcare.com",
      phone: "+213 555 003 003",
      status: "active",
    },
  ]);

  const [searchTerm, setSearchTerm] = useState("");
  const [newDoctor, setNewDoctor] = useState({
    name: "",
    specialty: "",
    experience: "",
    email: "",
    phone: "",
  });

  const handleAppointmentStatus = (id: number, newStatus: string) => {
    setAppointments((prev) =>
      prev.map((apt) => (apt.id === id ? { ...apt, status: newStatus } : apt)),
    );
  };

  const handleContactStatus = (id: number, newStatus: string) => {
    setContacts((prev) =>
      prev.map((contact) =>
        contact.id === id ? { ...contact, status: newStatus } : contact,
      ),
    );
  };

  const deleteAppointment = (id: number) => {
    setAppointments((prev) => prev.filter((apt) => apt.id !== id));
  };

  const deleteContact = (id: number) => {
    setContacts((prev) => prev.filter((contact) => contact.id !== id));
  };

  const deleteDoctor = (id: number) => {
    setDoctors((prev) => prev.filter((doctor) => doctor.id !== id));
  };

  const addDoctor = () => {
    if (newDoctor.name && newDoctor.specialty && newDoctor.experience) {
      const doctor = {
        id: doctors.length + 1,
        ...newDoctor,
        status: "active",
      };
      setDoctors((prev) => [...prev, doctor]);
      setNewDoctor({
        name: "",
        specialty: "",
        experience: "",
        email: "",
        phone: "",
      });
    }
  };

  const filteredAppointments = appointments.filter(
    (apt) =>
      apt.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      apt.doctorName.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const filteredContacts = contacts.filter(
    (contact) =>
      contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.subject.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Header */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-accent/10 py-12">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">
                Admin Dashboard
              </h1>
              <p className="text-muted-foreground">
                Manage appointments, contacts, and doctors
              </p>
            </div>
            <div className="bg-primary p-3 rounded-full">
              <Settings className="h-8 w-8 text-white" />
            </div>
          </div>
        </div>
      </section>

      {/* Dashboard Content */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          {/* Stats Cards */}
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">
                      Total Appointments
                    </p>
                    <p className="text-2xl font-bold">{appointments.length}</p>
                  </div>
                  <Calendar className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">
                      Pending Appointments
                    </p>
                    <p className="text-2xl font-bold">
                      {
                        appointments.filter((apt) => apt.status === "pending")
                          .length
                      }
                    </p>
                  </div>
                  <Clock className="h-8 w-8 text-yellow-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">
                      Active Doctors
                    </p>
                    <p className="text-2xl font-bold">{doctors.length}</p>
                  </div>
                  <Stethoscope className="h-8 w-8 text-accent" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">
                      Unread Messages
                    </p>
                    <p className="text-2xl font-bold">
                      {
                        contacts.filter(
                          (contact) => contact.status === "unread",
                        ).length
                      }
                    </p>
                  </div>
                  <Mail className="h-8 w-8 text-destructive" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="appointments" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="appointments">Appointments</TabsTrigger>
              <TabsTrigger value="contacts">Contact Messages</TabsTrigger>
              <TabsTrigger value="doctors">Doctors</TabsTrigger>
            </TabsList>

            {/* Appointments Tab */}
            <TabsContent value="appointments">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Appointment Requests</CardTitle>
                      <CardDescription>
                        Manage incoming appointment requests from patients
                      </CardDescription>
                    </div>
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search appointments..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-64"
                      />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Patient</TableHead>
                        <TableHead>Doctor</TableHead>
                        <TableHead>Date & Time</TableHead>
                        <TableHead>Contact</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredAppointments.map((appointment) => (
                        <TableRow key={appointment.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">
                                {appointment.patientName}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                {appointment.reason}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>{appointment.doctorName}</TableCell>
                          <TableCell>
                            <div>
                              <div>{appointment.date}</div>
                              <div className="text-sm text-muted-foreground">
                                {appointment.time}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div>
                              <div className="text-sm">{appointment.phone}</div>
                              <div className="text-sm text-muted-foreground">
                                {appointment.email}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                appointment.status === "confirmed"
                                  ? "default"
                                  : appointment.status === "pending"
                                    ? "secondary"
                                    : "destructive"
                              }
                            >
                              {appointment.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              {appointment.status === "pending" && (
                                <Button
                                  size="sm"
                                  onClick={() =>
                                    handleAppointmentStatus(
                                      appointment.id,
                                      "confirmed",
                                    )
                                  }
                                >
                                  <CheckCircle className="h-4 w-4 mr-1" />
                                  Confirm
                                </Button>
                              )}
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button size="sm" variant="destructive">
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>
                                      Delete Appointment
                                    </AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Are you sure you want to delete this
                                      appointment? This action cannot be undone.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>
                                      Cancel
                                    </AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() =>
                                        deleteAppointment(appointment.id)
                                      }
                                    >
                                      Delete
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Contacts Tab */}
            <TabsContent value="contacts">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Contact Messages</CardTitle>
                      <CardDescription>
                        Messages received from the contact form
                      </CardDescription>
                    </div>
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search messages..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-64"
                      />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name & Contact</TableHead>
                        <TableHead>Subject</TableHead>
                        <TableHead>Message</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredContacts.map((contact) => (
                        <TableRow key={contact.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{contact.name}</div>
                              <div className="text-sm text-muted-foreground">
                                {contact.email}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                {contact.phone}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>{contact.subject}</TableCell>
                          <TableCell>
                            <div className="max-w-xs truncate">
                              {contact.message}
                            </div>
                          </TableCell>
                          <TableCell>{contact.date}</TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                contact.status === "replied"
                                  ? "default"
                                  : "secondary"
                              }
                            >
                              {contact.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              {contact.status === "unread" && (
                                <Button
                                  size="sm"
                                  onClick={() =>
                                    handleContactStatus(contact.id, "replied")
                                  }
                                >
                                  Mark Replied
                                </Button>
                              )}
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button size="sm" variant="destructive">
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>
                                      Delete Message
                                    </AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Are you sure you want to delete this
                                      message? This action cannot be undone.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>
                                      Cancel
                                    </AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => deleteContact(contact.id)}
                                    >
                                      Delete
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Doctors Tab */}
            <TabsContent value="doctors">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Doctors Management</CardTitle>
                      <CardDescription>
                        Add, edit, and manage clinic doctors
                      </CardDescription>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button>
                          <Plus className="h-4 w-4 mr-2" />
                          Add Doctor
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Add New Doctor</DialogTitle>
                          <DialogDescription>
                            Enter the details for the new doctor.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="name">Full Name</Label>
                            <Input
                              id="name"
                              value={newDoctor.name}
                              onChange={(e) =>
                                setNewDoctor((prev) => ({
                                  ...prev,
                                  name: e.target.value,
                                }))
                              }
                              placeholder="Dr. John Doe"
                            />
                          </div>
                          <div>
                            <Label htmlFor="specialty">Specialty</Label>
                            <Input
                              id="specialty"
                              value={newDoctor.specialty}
                              onChange={(e) =>
                                setNewDoctor((prev) => ({
                                  ...prev,
                                  specialty: e.target.value,
                                }))
                              }
                              placeholder="Cardiologist"
                            />
                          </div>
                          <div>
                            <Label htmlFor="experience">
                              Years of Experience
                            </Label>
                            <Input
                              id="experience"
                              value={newDoctor.experience}
                              onChange={(e) =>
                                setNewDoctor((prev) => ({
                                  ...prev,
                                  experience: e.target.value,
                                }))
                              }
                              placeholder="10 years"
                            />
                          </div>
                          <div>
                            <Label htmlFor="email">Email</Label>
                            <Input
                              id="email"
                              type="email"
                              value={newDoctor.email}
                              onChange={(e) =>
                                setNewDoctor((prev) => ({
                                  ...prev,
                                  email: e.target.value,
                                }))
                              }
                              placeholder="doctor@heartcare.com"
                            />
                          </div>
                          <div>
                            <Label htmlFor="phone">Phone</Label>
                            <Input
                              id="phone"
                              value={newDoctor.phone}
                              onChange={(e) =>
                                setNewDoctor((prev) => ({
                                  ...prev,
                                  phone: e.target.value,
                                }))
                              }
                              placeholder="+213 555 000 000"
                            />
                          </div>
                          <Button onClick={addDoctor} className="w-full">
                            <UserPlus className="h-4 w-4 mr-2" />
                            Add Doctor
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Specialty</TableHead>
                        <TableHead>Experience</TableHead>
                        <TableHead>Contact</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {doctors.map((doctor) => (
                        <TableRow key={doctor.id}>
                          <TableCell className="font-medium">
                            {doctor.name}
                          </TableCell>
                          <TableCell>{doctor.specialty}</TableCell>
                          <TableCell>{doctor.experience}</TableCell>
                          <TableCell>
                            <div>
                              <div className="text-sm">{doctor.email}</div>
                              <div className="text-sm text-muted-foreground">
                                {doctor.phone}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="default">{doctor.status}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button size="sm" variant="destructive">
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>
                                      Delete Doctor
                                    </AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Are you sure you want to remove this
                                      doctor? This action cannot be undone.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>
                                      Cancel
                                    </AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => deleteDoctor(doctor.id)}
                                    >
                                      Delete
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  );
}
