import { ReactNode } from "react";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";
import { cn } from "@/lib/utils";

interface AnimatedSectionProps {
  children: ReactNode;
  className?: string;
  animation?: "fadeUp" | "fadeIn" | "slideLeft" | "slideRight" | "scale";
  delay?: number;
}

export const AnimatedSection = ({
  children,
  className,
  animation = "fadeUp",
  delay = 0,
}: AnimatedSectionProps) => {
  const { elementRef, isVisible } = useScrollAnimation();

  const getAnimationClasses = () => {
    const baseClasses = "transition-all duration-700 ease-out";

    switch (animation) {
      case "fadeUp":
        return cn(
          baseClasses,
          isVisible
            ? "opacity-100 transform translate-y-0"
            : "opacity-0 transform translate-y-8",
        );
      case "fadeIn":
        return cn(baseClasses, isVisible ? "opacity-100" : "opacity-0");
      case "slideLeft":
        return cn(
          baseClasses,
          isVisible
            ? "opacity-100 transform translate-x-0"
            : "opacity-0 transform translate-x-8",
        );
      case "slideRight":
        return cn(
          baseClasses,
          isVisible
            ? "opacity-100 transform translate-x-0"
            : "opacity-0 transform -translate-x-8",
        );
      case "scale":
        return cn(
          baseClasses,
          isVisible
            ? "opacity-100 transform scale-100"
            : "opacity-0 transform scale-95",
        );
      default:
        return baseClasses;
    }
  };

  return (
    <div
      ref={elementRef}
      className={cn(getAnimationClasses(), className)}
      style={{
        transitionDelay: `${delay}ms`,
      }}
    >
      {children}
    </div>
  );
};

export const StaggeredGrid = ({
  children,
  className,
  staggerDelay = 100,
}: {
  children: ReactNode[];
  className?: string;
  staggerDelay?: number;
}) => {
  const { elementRef, isVisible } = useScrollAnimation();

  return (
    <div ref={elementRef} className={className}>
      {Array.isArray(children) &&
        children.map((child, index) => (
          <div
            key={index}
            className={cn(
              "transition-all duration-700 ease-out",
              isVisible
                ? "opacity-100 transform translate-y-0"
                : "opacity-0 transform translate-y-8",
            )}
            style={{
              transitionDelay: `${index * staggerDelay}ms`,
            }}
          >
            {child}
          </div>
        ))}
    </div>
  );
};

export const AnimatedCard = ({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) => {
  const { elementRef, isVisible } = useScrollAnimation();

  return (
    <div
      ref={elementRef}
      className={cn(
        "transition-all duration-700 ease-out",
        isVisible
          ? "opacity-100 transform translate-y-0 scale-100"
          : "opacity-0 transform translate-y-8 scale-95",
        className,
      )}
      style={{
        transitionDelay: `${delay}ms`,
      }}
    >
      {children}
    </div>
  );
};

export const AnimatedText = ({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) => {
  const { elementRef, isVisible } = useScrollAnimation();

  return (
    <div
      ref={elementRef}
      className={cn(
        "transition-all duration-1000 ease-out",
        isVisible
          ? "opacity-100 transform translate-y-0"
          : "opacity-0 transform translate-y-4",
        className,
      )}
      style={{
        transitionDelay: `${delay}ms`,
      }}
    >
      {children}
    </div>
  );
};
