import { ReactNode } from "react";
import {
  useScrollAnimation,
  animationVariants,
} from "@/hooks/use-scroll-animation";
import { cn } from "@/lib/utils";

interface AnimatedSectionProps {
  children: ReactNode;
  className?: string;
  animation?: keyof typeof animationVariants;
  delay?: number;
  as?: "div" | "section" | "footer" | "header" | "main" | "article";
}

export function AnimatedSection({
  children,
  className,
  animation = "fadeInUp",
  delay = 0,
  as = "div",
}: AnimatedSectionProps) {
  const { ref, isVisible } = useScrollAnimation();
  const variant = animationVariants[animation];

  const animationClasses = cn(
    variant.initial,
    isVisible ? variant.animate : "",
    variant.transition,
    className,
  );

  const style = delay > 0 ? { transitionDelay: `${delay}ms` } : undefined;

  if (as === "section") {
    return (
      <section ref={ref as any} className={animationClasses} style={style}>
        {children}
      </section>
    );
  }

  if (as === "footer") {
    return (
      <footer ref={ref as any} className={animationClasses} style={style}>
        {children}
      </footer>
    );
  }

  if (as === "header") {
    return (
      <header ref={ref as any} className={animationClasses} style={style}>
        {children}
      </header>
    );
  }

  if (as === "main") {
    return (
      <main ref={ref as any} className={animationClasses} style={style}>
        {children}
      </main>
    );
  }

  if (as === "article") {
    return (
      <article ref={ref as any} className={animationClasses} style={style}>
        {children}
      </article>
    );
  }

  return (
    <div ref={ref as any} className={animationClasses} style={style}>
      {children}
    </div>
  );
}

// Staggered children animation component
interface StaggeredListProps {
  children: ReactNode[];
  className?: string;
  itemClassName?: string;
  delay?: number;
  as?: "div" | "ul" | "ol";
}

export function StaggeredList({
  children,
  className,
  itemClassName,
  delay = 100,
  as = "div",
}: StaggeredListProps) {
  const { ref, isVisible } = useScrollAnimation();

  const content = children.map((child, index) => (
    <div
      key={index}
      className={cn(
        "opacity-0 translate-y-8 transition-all duration-700 ease-out",
        isVisible ? "opacity-100 translate-y-0" : "",
        itemClassName,
      )}
      style={{
        transitionDelay: isVisible ? `${index * delay}ms` : "0ms",
      }}
    >
      {child}
    </div>
  ));

  if (as === "ul") {
    return (
      <ul ref={ref as any} className={className}>
        {content}
      </ul>
    );
  }

  if (as === "ol") {
    return (
      <ol ref={ref as any} className={className}>
        {content}
      </ol>
    );
  }

  return (
    <div ref={ref as any} className={className}>
      {content}
    </div>
  );
}
