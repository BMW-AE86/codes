import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function Navigation() {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="bg-white shadow-sm border-b">
      <div className="container mx-auto px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2">
            <img
              src="https://cdn.builder.io/api/v1/assets/b17779d745794a56a9caec5c1d59412f/logo-19-photoroom-53a91e?format=webp&width=800"
              alt="SteelFlow Pipes"
              className="h-8 w-8"
            />
            <span className="text-xl font-bold text-steelblue">
              SteelFlow Pipes
            </span>
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            <Link
              to="/"
              className={cn(
                "text-sm font-medium transition-colors hover:text-steelblue",
                isActive("/") ? "text-steelblue" : "text-muted-foreground",
              )}
            >
              Home
            </Link>
            <Link
              to="/about"
              className={cn(
                "text-sm font-medium transition-colors hover:text-steelblue",
                isActive("/about") ? "text-steelblue" : "text-muted-foreground",
              )}
            >
              About Us
            </Link>
            <Link
              to="/products"
              className={cn(
                "text-sm font-medium transition-colors hover:text-steelblue",
                isActive("/products")
                  ? "text-steelblue"
                  : "text-muted-foreground",
              )}
            >
              Products
            </Link>
            <Link
              to="/manufacturing"
              className={cn(
                "text-sm font-medium transition-colors hover:text-steelblue",
                isActive("/manufacturing")
                  ? "text-steelblue"
                  : "text-muted-foreground",
              )}
            >
              Manufacturing
            </Link>
            <Link
              to="/contact"
              className={cn(
                "text-sm font-medium transition-colors hover:text-steelblue",
                isActive("/contact")
                  ? "text-steelblue"
                  : "text-muted-foreground",
              )}
            >
              Contact
            </Link>
            <Button
              asChild
              className="bg-steelblue hover:bg-steelblue-dark text-white"
            >
              <Link to="/contact">Request Quote</Link>
            </Button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              asChild
              size="sm"
              className="bg-steelblue hover:bg-steelblue-dark text-white"
            >
              <Link to="/contact">Quote</Link>
            </Button>
          </div>
        </div>

        {/* Mobile menu */}
        <div className="md:hidden pb-4">
          <div className="flex flex-col space-y-2">
            <Link
              to="/"
              className={cn(
                "px-3 py-2 text-sm font-medium transition-colors hover:text-steelblue",
                isActive("/") ? "text-steelblue" : "text-muted-foreground",
              )}
            >
              Home
            </Link>
            <Link
              to="/about"
              className={cn(
                "px-3 py-2 text-sm font-medium transition-colors hover:text-steelblue",
                isActive("/about") ? "text-steelblue" : "text-muted-foreground",
              )}
            >
              About Us
            </Link>
            <Link
              to="/products"
              className={cn(
                "px-3 py-2 text-sm font-medium transition-colors hover:text-steelblue",
                isActive("/products")
                  ? "text-steelblue"
                  : "text-muted-foreground",
              )}
            >
              Products
            </Link>
            <Link
              to="/manufacturing"
              className={cn(
                "px-3 py-2 text-sm font-medium transition-colors hover:text-steelblue",
                isActive("/manufacturing")
                  ? "text-steelblue"
                  : "text-muted-foreground",
              )}
            >
              Manufacturing
            </Link>
            <Link
              to="/contact"
              className={cn(
                "px-3 py-2 text-sm font-medium transition-colors hover:text-steelblue",
                isActive("/contact")
                  ? "text-steelblue"
                  : "text-muted-foreground",
              )}
            >
              Contact
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
