import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "react-router-dom";
import {
  CheckCircle,
  Download,
  ArrowRight,
  Settings,
  Gauge,
  Droplets,
  Zap,
  Building,
  Wrench,
} from "lucide-react";
import { AnimatedSection } from "@/components/AnimatedSection";

export default function Products() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <AnimatedSection
        as="section"
        className="bg-gradient-to-r from-steelblue/10 to-industrial/10 py-16 lg:py-24"
      >
        <div className="container mx-auto px-8">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-4 bg-steelblue/10 text-steelblue">
              Product Catalog
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-industrial mb-6">
              Premium Pipe Solutions
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Comprehensive range of high-quality pipes engineered for diverse
              industrial applications. From water supply to oil & gas
              transmission, we deliver reliability and performance.
            </p>
          </div>
        </div>
      </AnimatedSection>

      {/* Product Categories */}
      <AnimatedSection
        as="section"
        className="py-16 lg:py-20"
        animation="fadeInUp"
      >
        <div className="container mx-auto px-8">
          <Tabs defaultValue="pvc" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-12">
              <TabsTrigger value="pvc" className="text-sm font-medium">
                PVC Pipes
              </TabsTrigger>
              <TabsTrigger value="hdpe" className="text-sm font-medium">
                HDPE Pipes
              </TabsTrigger>
              <TabsTrigger value="steel" className="text-sm font-medium">
                Steel Pipes
              </TabsTrigger>
            </TabsList>

            {/* PVC Pipes */}
            <TabsContent value="pvc">
              <div className="grid lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <h2 className="text-3xl font-bold text-steelblue mb-6">
                    PVC Pipe Systems
                  </h2>
                  <p className="text-muted-foreground mb-8 text-lg">
                    Our PVC pipes offer exceptional durability, chemical
                    resistance, and cost-effectiveness for water supply,
                    drainage, and irrigation applications.
                  </p>

                  <div className="grid md:grid-cols-2 gap-6 mb-8">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-steelblue flex items-center gap-2">
                          <Droplets className="h-5 w-5" />
                          Pressure Pipes
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-steelblue" />
                            Diameter: 20mm - 630mm
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-steelblue" />
                            Pressure: 4 bar - 25 bar
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-steelblue" />
                            Standards: ASTM D1785, EN 1452
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-steelblue" />
                            Applications: Water supply, irrigation
                          </li>
                        </ul>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-steelblue flex items-center gap-2">
                          <Settings className="h-5 w-5" />
                          Drainage Pipes
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-steelblue" />
                            Diameter: 75mm - 630mm
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-steelblue" />
                            Ring Stiffness: SN4, SN8, SN16
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-steelblue" />
                            Standards: ASTM F679, EN 1401
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-steelblue" />
                            Applications: Sewerage, stormwater
                          </li>
                        </ul>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="bg-steelblue/5 p-6 rounded-lg">
                    <h3 className="font-semibold text-steelblue mb-3">
                      Key Features
                    </h3>
                    <div className="grid md:grid-cols-3 gap-4 text-sm">
                      <div>• Corrosion resistant</div>
                      <div>• UV stabilized</div>
                      <div>• Smooth internal surface</div>
                      <div>• Lightweight installation</div>
                      <div>• Long service life (50+ years)</div>
                      <div>• Cost-effective solution</div>
                    </div>
                  </div>
                </div>

                <div>
                  <Card className="sticky top-6">
                    <CardHeader>
                      <CardTitle className="text-steelblue">
                        Technical Specifications
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">Available Sizes</h4>
                        <div className="text-sm text-muted-foreground">
                          20, 25, 32, 40, 50, 63, 75, 90, 110, 140, 160, 200,
                          250, 315, 400, 500, 630mm
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Pressure Classes</h4>
                        <div className="text-sm text-muted-foreground">
                          PN4, PN6, PN10, PN16, PN20, PN25
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Colors</h4>
                        <div className="text-sm text-muted-foreground">
                          Blue (pressure), Brown/Orange (drainage)
                        </div>
                      </div>
                      <Button
                        asChild
                        className="w-full bg-steelblue hover:bg-steelblue-dark"
                      >
                        <Link to="/contact">
                          <Download className="h-4 w-4 mr-2" />
                          Download Catalog
                        </Link>
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            {/* HDPE Pipes */}
            <TabsContent value="hdpe">
              <div className="grid lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <h2 className="text-3xl font-bold text-industrial mb-6">
                    HDPE Pipe Systems
                  </h2>
                  <p className="text-muted-foreground mb-8 text-lg">
                    High-density polyethylene pipes offering superior
                    flexibility, chemical resistance, and leak-free joints for
                    demanding applications.
                  </p>

                  <div className="grid md:grid-cols-2 gap-6 mb-8">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-industrial flex items-center gap-2">
                          <Gauge className="h-5 w-5" />
                          Gas Distribution
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-industrial" />
                            Diameter: 20mm - 630mm
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-industrial" />
                            Pressure: Up to 16 bar
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-industrial" />
                            Grade: PE80, PE100
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-industrial" />
                            Standards: ISO 4437, ASTM D2513
                          </li>
                        </ul>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-industrial flex items-center gap-2">
                          <Droplets className="h-5 w-5" />
                          Water Supply
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-industrial" />
                            Diameter: 16mm - 2000mm
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-industrial" />
                            Pressure: Up to 32 bar
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-industrial" />
                            Grade: PE80, PE100
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-industrial" />
                            Standards: ISO 4427, EN 12201
                          </li>
                        </ul>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="bg-industrial/5 p-6 rounded-lg">
                    <h3 className="font-semibold text-industrial mb-3">
                      Advantages
                    </h3>
                    <div className="grid md:grid-cols-3 gap-4 text-sm">
                      <div>• Flexible & tough</div>
                      <div>• Leak-free joints</div>
                      <div>• Chemical resistant</div>
                      <div>• Earthquake resistant</div>
                      <div>• Easy installation</div>
                      <div>• Fusion welding capability</div>
                    </div>
                  </div>
                </div>

                <div>
                  <Card className="sticky top-6">
                    <CardHeader>
                      <CardTitle className="text-industrial">
                        HDPE Specifications
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">PE100 Grades</h4>
                        <div className="text-sm text-muted-foreground">
                          SDR9, SDR11, SDR13.6, SDR17, SDR21, SDR26, SDR33
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Temperature Range</h4>
                        <div className="text-sm text-muted-foreground">
                          -40°C to +60°C continuous operation
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Joining Methods</h4>
                        <div className="text-sm text-muted-foreground">
                          Butt fusion, electrofusion, mechanical fittings
                        </div>
                      </div>
                      <Button
                        asChild
                        className="w-full bg-industrial hover:bg-industrial-dark"
                      >
                        <Link to="/contact">
                          <Download className="h-4 w-4 mr-2" />
                          Download Catalog
                        </Link>
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            {/* Steel Pipes */}
            <TabsContent value="steel">
              <div className="grid lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <h2 className="text-3xl font-bold text-steel mb-6">
                    Steel Pipe Systems
                  </h2>
                  <p className="text-muted-foreground mb-8 text-lg">
                    Heavy-duty steel pipes engineered for high-pressure
                    applications in oil, gas, and industrial infrastructure with
                    superior strength and durability.
                  </p>

                  <div className="grid md:grid-cols-2 gap-6 mb-8">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-steel flex items-center gap-2">
                          <Zap className="h-5 w-5" />
                          Seamless Pipes
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-steel" />
                            Diameter: 15mm - 914mm
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-steel" />
                            Wall Thickness: 2mm - 80mm
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-steel" />
                            Grades: API 5L X42 to X80
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-steel" />
                            Standards: API 5L, ASTM A106/A53
                          </li>
                        </ul>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-steel flex items-center gap-2">
                          <Building className="h-5 w-5" />
                          Welded Pipes
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2 text-sm">
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-steel" />
                            Diameter: 219mm - 2540mm
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-steel" />
                            Wall Thickness: 3mm - 50mm
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-steel" />
                            Grades: API 5L PSL1 & PSL2
                          </li>
                          <li className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-steel" />
                            Standards: API 5L, EN 10219
                          </li>
                        </ul>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="bg-steel/5 p-6 rounded-lg">
                    <h3 className="font-semibold text-steel mb-3">
                      Applications & Features
                    </h3>
                    <div className="grid md:grid-cols-3 gap-4 text-sm">
                      <div>• Oil & gas transmission</div>
                      <div>• High pressure systems</div>
                      <div>• Structural applications</div>
                      <div>• Superior strength</div>
                      <div>• High temperature resistance</div>
                      <div>• Welding compatible</div>
                    </div>
                  </div>
                </div>

                <div>
                  <Card className="sticky top-6">
                    <CardHeader>
                      <CardTitle className="text-steel">
                        Steel Specifications
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">Material Grades</h4>
                        <div className="text-sm text-muted-foreground">
                          X42, X46, X52, X56, X60, X65, X70, X80
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Pressure Rating</h4>
                        <div className="text-sm text-muted-foreground">
                          Up to 420 bar (6000 PSI)
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Coatings</h4>
                        <div className="text-sm text-muted-foreground">
                          3LPE, 3LPP, FBE, internal lining available
                        </div>
                      </div>
                      <Button
                        asChild
                        className="w-full bg-steel hover:bg-steel-dark"
                      >
                        <Link to="/contact">
                          <Download className="h-4 w-4 mr-2" />
                          Download Catalog
                        </Link>
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </AnimatedSection>

      {/* Custom Solutions */}
      <AnimatedSection
        as="section"
        className="py-16 lg:py-20 bg-gray-50"
        animation="fadeInUp"
      >
        <div className="container mx-auto px-8">
          <div className="max-w-4xl mx-auto text-center mb-12">
            <Badge className="mb-4 bg-steelblue/10 text-steelblue">
              Custom Solutions
            </Badge>
            <h2 className="text-3xl lg:text-4xl font-bold text-industrial mb-6">
              Engineered for Your Specific Needs
            </h2>
            <p className="text-lg text-muted-foreground">
              Beyond our standard product range, we offer custom pipe solutions
              designed to meet unique project requirements and specifications.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <div className="w-16 h-16 bg-steelblue/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Wrench className="h-8 w-8 text-steelblue" />
                </div>
                <CardTitle className="text-steelblue">
                  Custom Specifications
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Tailored dimensions, wall thickness, and material grades to
                  meet your exact project requirements.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-16 h-16 bg-industrial/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Settings className="h-8 w-8 text-industrial" />
                </div>
                <CardTitle className="text-industrial">
                  Special Coatings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Protective coatings and linings for corrosive environments and
                  specialized applications.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-16 h-16 bg-steel/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="h-8 w-8 text-steel" />
                </div>
                <CardTitle className="text-steel">
                  Testing & Certification
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Comprehensive testing protocols and certification to ensure
                  compliance with industry standards.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </AnimatedSection>

      {/* CTA Section */}
      <AnimatedSection
        as="section"
        className="py-16 lg:py-20 bg-gradient-to-r from-steelblue to-industrial text-white"
        animation="fadeInUp"
      >
        <div className="container mx-auto px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Need Help Selecting the Right Pipe?
          </h2>
          <p className="text-xl mb-8 text-blue-100 max-w-2xl mx-auto">
            Our technical experts are ready to help you choose the perfect pipe
            solution for your project requirements.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              className="bg-white text-steelblue hover:bg-gray-100 font-semibold"
            >
              <Link to="/contact">
                Get Technical Consultation{" "}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="bg-white text-gray-600 border-white hover:bg-white hover:text-steelblue"
            >
              <Link to="/manufacturing">View Our Process</Link>
            </Button>
          </div>
        </div>
      </AnimatedSection>
    </div>
  );
}
