import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import {
  Building2,
  Factory,
  Truck,
  Shield,
  ArrowRight,
  Phone,
  Mail,
  MapPin,
} from "lucide-react";
import { AnimatedSection } from "@/components/AnimatedSection";

export default function Index() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-steelblue via-steelblue-dark to-industrial text-white">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative container mx-auto px-8 py-24 lg:py-32">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6 bg-white/20 text-white hover:bg-white/30">
              Precision Engineering Since 1995
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Precision Engineered Pipes for Every Industry
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-100">
              Leading manufacturer of high-quality PVC, HDPE, and Steel pipes
              serving construction, agriculture, water supply, and oil & gas
              industries worldwide.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                asChild
                size="lg"
                className="bg-white text-steelblue hover:bg-gray-100 font-semibold"
              >
                <Link to="/contact">
                  Request a Quote <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="bg-white text-gray-600 border-white hover:bg-white hover:text-steelblue"
              >
                <Link to="/products">View Products</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* About Us Preview */}
      <AnimatedSection as="section" className="py-16 lg:py-24 bg-gray-50">
        <div className="container mx-auto px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-steelblue/10 text-steelblue">
                About SteelFlow Pipes
              </Badge>
              <h2 className="text-3xl lg:text-4xl font-bold text-industrial mb-6">
                25+ Years of Manufacturing Excellence
              </h2>
              <p className="text-lg text-muted-foreground mb-6">
                Founded in 1995, SteelFlow Pipes has grown from a small family
                business into a leading pipe manufacturer. Our commitment to
                quality, innovation, and customer satisfaction has made us a
                trusted partner across industries.
              </p>
              <div className="grid grid-cols-2 gap-6 mb-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-steelblue">50K+</div>
                  <div className="text-sm text-muted-foreground">
                    Projects Completed
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-steelblue">25+</div>
                  <div className="text-sm text-muted-foreground">
                    Years Experience
                  </div>
                </div>
              </div>
              <Button asChild className="bg-steelblue hover:bg-steelblue-dark">
                <Link to="/about">Learn More About Us</Link>
              </Button>
            </div>
            <div className="bg-gradient-to-br from-steelblue/10 to-industrial/10 p-8 rounded-lg">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-lg text-center">
                  <Shield className="h-8 w-8 text-steelblue mx-auto mb-2" />
                  <div className="font-semibold text-sm">ISO 9001:2015</div>
                  <div className="text-xs text-muted-foreground">
                    Certified Quality
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg text-center">
                  <Factory className="h-8 w-8 text-steelblue mx-auto mb-2" />
                  <div className="font-semibold text-sm">10K Tons/Month</div>
                  <div className="text-xs text-muted-foreground">
                    Production Capacity
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg text-center">
                  <Truck className="h-8 w-8 text-steelblue mx-auto mb-2" />
                  <div className="font-semibold text-sm">Global Reach</div>
                  <div className="text-xs text-muted-foreground">
                    Worldwide Delivery
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg text-center">
                  <Building2 className="h-8 w-8 text-steelblue mx-auto mb-2" />
                  <div className="font-semibold text-sm">Multi-Industry</div>
                  <div className="text-xs text-muted-foreground">
                    Applications
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </AnimatedSection>

      {/* Featured Products */}
      <AnimatedSection as="section" className="py-16 lg:py-24">
        <div className="container mx-auto px-8">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-steelblue/10 text-steelblue">
              Our Products
            </Badge>
            <h2 className="text-3xl lg:text-4xl font-bold text-industrial mb-4">
              Premium Pipe Solutions
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              We manufacture a comprehensive range of pipes designed to meet the
              demanding requirements of various industries.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-steelblue/10 rounded-lg flex items-center justify-center mb-4">
                  <div className="w-6 h-6 bg-steelblue rounded-full"></div>
                </div>
                <CardTitle className="text-steelblue">PVC Pipes</CardTitle>
                <CardDescription>
                  Pressure & Non-pressure applications
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-muted-foreground space-y-2 mb-4">
                  <li>• Diameter: 20mm - 630mm</li>
                  <li>• Pressure: Up to 25 bar</li>
                  <li>• Applications: Water supply, drainage</li>
                  <li>• Standards: ASTM, EN, ISO</li>
                </ul>
                <Button asChild variant="outline" className="w-full">
                  <Link to="/contact">Request Quote</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-industrial/10 rounded-lg flex items-center justify-center mb-4">
                  <div className="w-6 h-6 bg-industrial rounded-full"></div>
                </div>
                <CardTitle className="text-industrial">HDPE Pipes</CardTitle>
                <CardDescription>
                  High-density polyethylene solutions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-muted-foreground space-y-2 mb-4">
                  <li>• Diameter: 16mm - 2000mm</li>
                  <li>• Pressure: Up to 32 bar</li>
                  <li>• Applications: Gas, water, mining</li>
                  <li>• Standards: PE80, PE100</li>
                </ul>
                <Button asChild variant="outline" className="w-full">
                  <Link to="/contact">Request Quote</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-steel/10 rounded-lg flex items-center justify-center mb-4">
                  <div className="w-6 h-6 bg-steel rounded-full"></div>
                </div>
                <CardTitle className="text-steel">Steel Pipes</CardTitle>
                <CardDescription>
                  Heavy-duty industrial applications
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-muted-foreground space-y-2 mb-4">
                  <li>• Diameter: 15mm - 2540mm</li>
                  <li>• Pressure: Up to 420 bar</li>
                  <li>• Applications: Oil, gas, structural</li>
                  <li>• Standards: API 5L, ASTM</li>
                </ul>
                <Button asChild variant="outline" className="w-full">
                  <Link to="/contact">Request Quote</Link>
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-12">
            <Button
              asChild
              size="lg"
              className="bg-steelblue hover:bg-steelblue-dark"
            >
              <Link to="/products">
                View All Products <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </AnimatedSection>

      {/* Industries Served */}
      <AnimatedSection as="section" className="py-16 lg:py-24 bg-gray-50">
        <div className="container mx-auto px-8">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-steelblue/10 text-steelblue">
              Industries We Serve
            </Badge>
            <h2 className="text-3xl lg:text-4xl font-bold text-industrial mb-4">
              Trusted Across Industries
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our pipes power essential infrastructure across multiple sectors,
              delivering reliability where it matters most.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-lg text-center hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-steelblue/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Building2 className="h-8 w-8 text-steelblue" />
              </div>
              <h3 className="font-semibold text-industrial mb-2">
                Construction
              </h3>
              <p className="text-sm text-muted-foreground">
                Building infrastructure, plumbing, and structural applications
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg text-center hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-industrial/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Factory className="h-8 w-8 text-industrial" />
              </div>
              <h3 className="font-semibold text-industrial mb-2">
                Agriculture
              </h3>
              <p className="text-sm text-muted-foreground">
                Irrigation systems, drainage, and agricultural water management
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg text-center hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-steel/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Truck className="h-8 w-8 text-steel" />
              </div>
              <h3 className="font-semibold text-industrial mb-2">
                Water Supply
              </h3>
              <p className="text-sm text-muted-foreground">
                Municipal water systems, distribution networks, and utilities
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg text-center hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 bg-steelblue/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-steelblue" />
              </div>
              <h3 className="font-semibold text-industrial mb-2">Oil & Gas</h3>
              <p className="text-sm text-muted-foreground">
                Pipeline infrastructure, refineries, and energy transmission
              </p>
            </div>
          </div>
        </div>
      </AnimatedSection>

      {/* CTA Section */}
      <AnimatedSection
        as="section"
        className="py-16 lg:py-24 bg-gradient-to-r from-steelblue to-industrial text-white"
      >
        <div className="container mx-auto px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Ready to Start Your Project?
          </h2>
          <p className="text-xl mb-8 text-blue-100 max-w-2xl mx-auto">
            Get a customized quote for your pipe requirements. Our team of
            experts will help you find the perfect solution for your project.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              className="bg-white text-steelblue hover:bg-gray-100 font-semibold"
            >
              <Link to="/contact">
                Get Free Quote <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <div className="flex items-center justify-center gap-6 text-blue-100">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <span className="text-sm">+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <span className="text-sm">info@steelflowpipes.com</span>
              </div>
            </div>
          </div>
        </div>
      </AnimatedSection>

      {/* Footer */}
      <AnimatedSection as="footer" className="bg-industrial text-white py-12">
        <div className="container mx-auto px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <img
                  src="https://cdn.builder.io/api/v1/assets/b17779d745794a56a9caec5c1d59412f/logo-19-photoroom-53a91e?format=webp&width=800"
                  alt="SteelFlow Pipes"
                  className="h-8 w-8"
                />
                <span className="text-xl font-bold">SteelFlow Pipes</span>
              </div>
              <p className="text-gray-300 text-sm">
                Precision engineered pipes for every industry. Quality you can
                trust, service you can count on.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>
                  <Link
                    to="/about"
                    className="hover:text-white transition-colors"
                  >
                    About Us
                  </Link>
                </li>
                <li>
                  <Link
                    to="/manufacturing"
                    className="hover:text-white transition-colors"
                  >
                    Manufacturing
                  </Link>
                </li>
                <li>
                  <Link
                    to="/products"
                    className="hover:text-white transition-colors"
                  >
                    Products
                  </Link>
                </li>
                <li>
                  <Link
                    to="/contact"
                    className="hover:text-white transition-colors"
                  >
                    Contact
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Products</h3>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>PVC Pipes</li>
                <li>HDPE Pipes</li>
                <li>Steel Pipes</li>
                <li>Custom Solutions</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Contact Info</h3>
              <div className="space-y-2 text-sm text-gray-300">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  <span>Industrial District, Manufacturing Hub</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  <span>+1 (555) 123-4567</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  <span>info@steelflowpipes.com</span>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-600 mt-8 pt-8 text-center">
            <p className="text-sm text-gray-300">
              © 2024 SteelFlow Pipes. All rights reserved. | ISO 9001:2015
              Certified
            </p>
          </div>
        </div>
      </AnimatedSection>
    </div>
  );
}
