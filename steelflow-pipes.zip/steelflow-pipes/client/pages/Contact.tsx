import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  Send,
  FileUp,
  CheckCircle,
  Building2,
  Users,
  Headphones,
  Globe,
} from "lucide-react";
import { AnimatedSection } from "@/components/AnimatedSection";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    company: "",
    pipeType: "",
    message: "",
    file: null as File | null,
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (value: string) => {
    setFormData((prev) => ({ ...prev, pipeType: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setFormData((prev) => ({ ...prev, file }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 2000);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="max-w-md mx-auto text-center p-8">
          <div className="w-16 h-16 bg-steelblue/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-8 w-8 text-steelblue" />
          </div>
          <h2 className="text-2xl font-bold text-industrial mb-4">
            Quote Request Submitted!
          </h2>
          <p className="text-muted-foreground mb-6">
            Thank you for your interest in SteelFlow Pipes. Our team will review
            your requirements and respond within 24 hours.
          </p>
          <Button
            onClick={() => {
              setIsSubmitted(false);
              setFormData({
                name: "",
                phone: "",
                email: "",
                company: "",
                pipeType: "",
                message: "",
                file: null,
              });
            }}
            className="bg-steelblue hover:bg-steelblue-dark"
          >
            Submit Another Request
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <AnimatedSection
        as="section"
        className="bg-gradient-to-r from-steelblue/10 to-industrial/10 py-16 lg:py-20"
      >
        <div className="container mx-auto px-8">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-4 bg-steelblue/10 text-steelblue">
              Get In Touch
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-industrial mb-6">
              Request a Quote
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Ready to start your project? Get a customized quote for your pipe
              requirements. Our expert team will help you find the perfect
              solution.
            </p>
          </div>
        </div>
      </AnimatedSection>

      {/* Contact Methods */}
      <AnimatedSection
        as="section"
        className="py-12 bg-white"
        animation="fadeInUp"
      >
        <div className="container mx-auto px-8">
          <div className="grid md:grid-cols-4 gap-6">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-steelblue/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Phone className="h-6 w-6 text-steelblue" />
                </div>
                <h3 className="font-semibold text-industrial mb-2">Call Us</h3>
                <p className="text-muted-foreground text-sm mb-2">
                  Speak directly with our experts
                </p>
                <p className="text-steelblue font-medium">+1 (555) 123-4567</p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-industrial/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Mail className="h-6 w-6 text-industrial" />
                </div>
                <h3 className="font-semibold text-industrial mb-2">Email Us</h3>
                <p className="text-muted-foreground text-sm mb-2">
                  Send detailed requirements
                </p>
                <p className="text-steelblue font-medium">
                  info@steelflowpipes.com
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-steel/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MapPin className="h-6 w-6 text-steel" />
                </div>
                <h3 className="font-semibold text-industrial mb-2">Visit Us</h3>
                <p className="text-muted-foreground text-sm mb-2">
                  Tour our manufacturing facility
                </p>
                <p className="text-steelblue font-medium text-sm">
                  Industrial District, Manufacturing Hub
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-steelblue/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="h-6 w-6 text-steelblue" />
                </div>
                <h3 className="font-semibold text-industrial mb-2">
                  Business Hours
                </h3>
                <p className="text-muted-foreground text-sm mb-2">
                  Monday - Friday
                </p>
                <p className="text-steelblue font-medium">8:00 AM - 6:00 PM</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </AnimatedSection>

      {/* Main Content */}
      <AnimatedSection
        as="section"
        className="py-16 lg:py-20"
        animation="fadeInUp"
      >
        <div className="container mx-auto px-8">
          <div className="grid lg:grid-cols-3 gap-12">
            {/* Quote Request Form */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-2xl text-steelblue flex items-center gap-2">
                    <Send className="h-6 w-6" />
                    Request a Quote
                  </CardTitle>
                  <CardDescription>
                    Fill out the form below and our team will get back to you
                    within 24 hours with a detailed quote.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">
                          Full Name <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="name"
                          name="name"
                          value={formData.name}
                          onChange={handleInputChange}
                          placeholder="Enter your full name"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">
                          Email Address <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          placeholder="Enter your email"
                          required
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="phone">
                          Phone Number <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="phone"
                          name="phone"
                          type="tel"
                          value={formData.phone}
                          onChange={handleInputChange}
                          placeholder="+1 (555) 123-4567"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="company">Company Name</Label>
                        <Input
                          id="company"
                          name="company"
                          value={formData.company}
                          onChange={handleInputChange}
                          placeholder="Enter company name (optional)"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="pipeType">
                        Type of Pipe Needed{" "}
                        <span className="text-red-500">*</span>
                      </Label>
                      <Select
                        onValueChange={handleSelectChange}
                        value={formData.pipeType}
                        required
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select pipe type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pvc-pressure">
                            PVC Pressure Pipes
                          </SelectItem>
                          <SelectItem value="pvc-drainage">
                            PVC Drainage Pipes
                          </SelectItem>
                          <SelectItem value="hdpe-gas">
                            HDPE Gas Distribution
                          </SelectItem>
                          <SelectItem value="hdpe-water">
                            HDPE Water Supply
                          </SelectItem>
                          <SelectItem value="steel-seamless">
                            Steel Seamless Pipes
                          </SelectItem>
                          <SelectItem value="steel-welded">
                            Steel Welded Pipes
                          </SelectItem>
                          <SelectItem value="custom">
                            Custom Solution
                          </SelectItem>
                          <SelectItem value="not-sure">Not Sure</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message">
                        Project Details & Requirements{" "}
                        <span className="text-red-500">*</span>
                      </Label>
                      <Textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        placeholder="Please describe your project requirements, including diameter, pressure rating, length needed, application, and any special specifications..."
                        rows={5}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="file">
                        Technical Drawings or Specifications
                      </Label>
                      <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center hover:border-steelblue/50 transition-colors">
                        <FileUp className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                        <Label
                          htmlFor="file"
                          className="cursor-pointer text-sm text-muted-foreground hover:text-steelblue"
                        >
                          Click to upload files or drag and drop
                          <br />
                          <span className="text-xs">
                            PDF, DWG, PNG, JPG up to 10MB
                          </span>
                        </Label>
                        <Input
                          id="file"
                          type="file"
                          onChange={handleFileChange}
                          className="hidden"
                          accept=".pdf,.dwg,.png,.jpg,.jpeg"
                        />
                        {formData.file && (
                          <p className="mt-2 text-sm text-steelblue">
                            Selected: {formData.file.name}
                          </p>
                        )}
                      </div>
                    </div>

                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-steelblue hover:bg-steelblue-dark"
                      size="lg"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Submitting...
                        </>
                      ) : (
                        <>
                          <Send className="h-4 w-4 mr-2" />
                          Submit Quote Request
                        </>
                      )}
                    </Button>

                    <p className="text-xs text-muted-foreground text-center">
                      By submitting this form, you agree to our terms of service
                      and privacy policy.
                    </p>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Contact Information & Support */}
            <div className="space-y-6">
              {/* Contact Details */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-steelblue">
                    Contact Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-steelblue mt-1 flex-shrink-0" />
                    <div>
                      <div className="font-medium">Address</div>
                      <div className="text-sm text-muted-foreground">
                        SteelFlow Pipes Manufacturing
                        <br />
                        Industrial District
                        <br />
                        Manufacturing Hub, MH 12345
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Phone className="h-5 w-5 text-steelblue mt-1 flex-shrink-0" />
                    <div>
                      <div className="font-medium">Phone</div>
                      <div className="text-sm text-muted-foreground">
                        Main: +1 (555) 123-4567
                        <br />
                        Sales: +1 (555) 123-4568
                        <br />
                        Support: +1 (555) 123-4569
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Mail className="h-5 w-5 text-steelblue mt-1 flex-shrink-0" />
                    <div>
                      <div className="font-medium">Email</div>
                      <div className="text-sm text-muted-foreground">
                        General: info@steelflowpipes.com
                        <br />
                        Sales: sales@steelflowpipes.com
                        <br />
                        Support: support@steelflowpipes.com
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock className="h-5 w-5 text-steelblue mt-1 flex-shrink-0" />
                    <div>
                      <div className="font-medium">Business Hours</div>
                      <div className="text-sm text-muted-foreground">
                        Monday - Friday: 8:00 AM - 6:00 PM
                        <br />
                        Saturday: 9:00 AM - 2:00 PM
                        <br />
                        Sunday: Closed
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Support Options */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-industrial">
                    Additional Support
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-3 p-3 bg-steelblue/5 rounded-lg">
                    <Building2 className="h-5 w-5 text-steelblue" />
                    <div>
                      <div className="font-medium text-sm">Facility Tours</div>
                      <div className="text-xs text-muted-foreground">
                        Schedule a visit to see our operations
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 bg-industrial/5 rounded-lg">
                    <Users className="h-5 w-5 text-industrial" />
                    <div>
                      <div className="font-medium text-sm">
                        Technical Consultation
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Expert advice for your project
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 bg-steel/5 rounded-lg">
                    <Headphones className="h-5 w-5 text-steel" />
                    <div>
                      <div className="font-medium text-sm">24/7 Support</div>
                      <div className="text-xs text-muted-foreground">
                        Emergency support for urgent needs
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 bg-steelblue/5 rounded-lg">
                    <Globe className="h-5 w-5 text-steelblue" />
                    <div>
                      <div className="font-medium text-sm">Global Shipping</div>
                      <div className="text-xs text-muted-foreground">
                        Worldwide delivery and logistics
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Stats */}
              <Card className="bg-gradient-to-br from-steelblue/10 to-industrial/10">
                <CardHeader>
                  <CardTitle className="text-industrial">
                    Why Choose SteelFlow?
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-steelblue">
                        25+
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Years Experience
                      </div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-steelblue">
                        50K+
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Projects Completed
                      </div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-steelblue">
                        24h
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Quote Response
                      </div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-steelblue">
                        ISO
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Certified Quality
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </AnimatedSection>

      {/* FAQ Section */}
      <AnimatedSection
        as="section"
        className="py-16 lg:py-20 bg-gray-50"
        animation="fadeInUp"
      >
        <div className="container mx-auto px-8">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <Badge className="mb-4 bg-steelblue/10 text-steelblue">
                Frequently Asked Questions
              </Badge>
              <h2 className="text-3xl lg:text-4xl font-bold text-industrial mb-4">
                Common Questions
              </h2>
              <p className="text-lg text-muted-foreground">
                Quick answers to help you get started with your pipe project.
              </p>
            </div>

            <Tabs defaultValue="general" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="general">General</TabsTrigger>
                <TabsTrigger value="technical">Technical</TabsTrigger>
                <TabsTrigger value="ordering">Ordering</TabsTrigger>
              </TabsList>

              <TabsContent value="general" className="mt-6">
                <div className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">
                        How quickly can you provide a quote?
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">
                        We provide detailed quotes within 24 hours for standard
                        products. Custom solutions may take 2-3 business days
                        depending on complexity.
                      </p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">
                        Do you offer international shipping?
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">
                        Yes, we ship worldwide. Our logistics team handles all
                        export documentation and can arrange door-to-door
                        delivery to your project site.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="technical" className="mt-6">
                <div className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">
                        What standards do your pipes meet?
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">
                        Our pipes comply with international standards including
                        ASTM, EN, ISO, API 5L, and many others. We can also
                        manufacture to customer-specific standards.
                      </p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">
                        Can you provide custom specifications?
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">
                        Absolutely. We offer custom diameters, wall thickness,
                        materials, and coatings to meet your specific project
                        requirements.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="ordering" className="mt-6">
                <div className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">
                        What is your minimum order quantity?
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">
                        Minimum orders vary by product type. For standard pipes,
                        it's typically 100 meters. We can accommodate smaller
                        quantities for custom products.
                      </p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">
                        What are your payment terms?
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">
                        We offer flexible payment terms including 30% advance,
                        70% on delivery. Letter of credit and other arrangements
                        are available for international orders.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </AnimatedSection>
    </div>
  );
}
