import { AnimatedSection } from "@/components/AnimatedSection";

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      <AnimatedSection as="section" className="py-16">
        <div className="container mx-auto px-8">
          <h1 className="text-4xl font-bold text-steelblue mb-8">
            About SteelFlow Pipes
          </h1>

          <AnimatedSection
            className="grid lg:grid-cols-2 gap-12 mb-16"
            animation="fadeInUp"
            delay={200}
          >
            <div>
              <h2 className="text-2xl font-semibold text-industrial mb-4">
                Our Story
              </h2>
              <p className="text-muted-foreground mb-4">
                Founded in 1995, SteelFlow Pipes has been at the forefront of
                pipe manufacturing for over 25 years. What started as a small
                family business has grown into a leading manufacturer serving
                industries across the globe.
              </p>
              <p className="text-muted-foreground">
                Our commitment to quality, innovation, and customer satisfaction
                has made us a trusted partner for construction, agriculture,
                water supply, and oil & gas industries.
              </p>
            </div>

            <div className="bg-steel-light/10 p-6 rounded-lg">
              <h3 className="text-xl font-semibold text-steelblue mb-4">
                Mission Statement
              </h3>
              <p className="text-muted-foreground">
                To deliver precision-engineered pipe solutions that meet the
                highest standards of quality and durability while maintaining
                competitive pricing and exceptional customer service.
              </p>
            </div>
          </AnimatedSection>

          <AnimatedSection
            className="grid md:grid-cols-3 gap-8 mb-16"
            animation="fadeInUp"
            delay={400}
          >
            <div className="text-center">
              <div className="bg-steelblue text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">25+</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Years Experience</h3>
              <p className="text-muted-foreground">
                Over two decades of manufacturing excellence
              </p>
            </div>

            <div className="text-center">
              <div className="bg-industrial text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">50K+</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Projects Completed</h3>
              <p className="text-muted-foreground">
                Successful installations worldwide
              </p>
            </div>

            <div className="text-center">
              <div className="bg-steel text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">ISO</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Certified Quality</h3>
              <p className="text-muted-foreground">
                ISO 9001:2015 quality management
              </p>
            </div>
          </AnimatedSection>

          <AnimatedSection
            className="bg-gradient-to-r from-steelblue/10 to-industrial/10 p-8 rounded-lg"
            animation="fadeInUp"
            delay={600}
          >
            <h2 className="text-2xl font-semibold text-steelblue mb-6">
              Manufacturing Capabilities
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-industrial mb-2">
                  Production Capacity
                </h3>
                <p className="text-muted-foreground mb-4">
                  Our state-of-the-art facility can produce up to 10,000 tons of
                  pipes monthly, with diameter ranges from 20mm to 2000mm.
                </p>

                <h3 className="font-semibold text-industrial mb-2">
                  Quality Control
                </h3>
                <p className="text-muted-foreground">
                  Every pipe undergoes rigorous testing including pressure
                  testing, dimensional verification, and material composition
                  analysis.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-industrial mb-2">
                  Certifications
                </h3>
                <ul className="list-disc list-inside text-muted-foreground space-y-1">
                  <li>ISO 9001:2015 Quality Management</li>
                  <li>ASTM Standards Compliance</li>
                  <li>EN 12201 for PE pipes</li>
                  <li>API 5L for steel pipes</li>
                  <li>NSF/ANSI 61 for potable water</li>
                </ul>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </AnimatedSection>
    </div>
  );
}
