import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Link } from "react-router-dom";
import {
  Factory,
  Settings,
  Shield,
  Truck,
  Clock,
  Users,
  Award,
  BarChart3,
  CheckCircle2,
  ArrowRight,
  Cog,
  FlaskConical,
  PackageCheck,
  TrendingUp,
} from "lucide-react";
import { AnimatedSection } from "@/components/AnimatedSection";

export default function Manufacturing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <AnimatedSection
        as="section"
        className="bg-gradient-to-r from-industrial/10 to-steelblue/10 py-16 lg:py-24"
      >
        <div className="container mx-auto px-8">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-4 bg-industrial/10 text-industrial">
              Manufacturing Excellence
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-industrial mb-6">
              Advanced Manufacturing Process
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              State-of-the-art facilities, precision machinery, and rigorous
              quality control ensure every pipe meets the highest standards of
              performance and reliability.
            </p>
            <div className="grid md:grid-cols-3 gap-6 mt-12">
              <div className="text-center">
                <div className="text-3xl font-bold text-steelblue">10,000</div>
                <div className="text-sm text-muted-foreground">
                  Tons/Month Capacity
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-steelblue">99.9%</div>
                <div className="text-sm text-muted-foreground">
                  Quality Pass Rate
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-steelblue">24/7</div>
                <div className="text-sm text-muted-foreground">
                  Production Schedule
                </div>
              </div>
            </div>
          </div>
        </div>
      </AnimatedSection>

      {/* Manufacturing Process Steps */}
      <AnimatedSection
        as="section"
        className="py-16 lg:py-20"
        animation="fadeInUp"
      >
        <div className="container mx-auto px-8">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-steelblue/10 text-steelblue">
              Our Process
            </Badge>
            <h2 className="text-3xl lg:text-4xl font-bold text-industrial mb-4">
              From Raw Materials to Finished Products
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our streamlined manufacturing process combines advanced technology
              with skilled craftsmanship to deliver superior pipe products.
            </p>
          </div>

          <div className="grid lg:grid-cols-4 gap-8">
            <Card className="relative overflow-hidden">
              <div className="absolute top-4 right-4 w-8 h-8 bg-steelblue text-white rounded-full flex items-center justify-center text-sm font-bold">
                1
              </div>
              <CardHeader>
                <div className="w-16 h-16 bg-steelblue/10 rounded-full flex items-center justify-center mb-4">
                  <PackageCheck className="h-8 w-8 text-steelblue" />
                </div>
                <CardTitle className="text-steelblue">
                  Raw Material Sourcing
                </CardTitle>
                <CardDescription>
                  Premium grade materials from certified suppliers
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-steelblue" />
                    Virgin PVC & PE resins
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-steelblue" />
                    High-grade steel coils
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-steelblue" />
                    Certified additives
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-steelblue" />
                    Incoming quality inspection
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden">
              <div className="absolute top-4 right-4 w-8 h-8 bg-industrial text-white rounded-full flex items-center justify-center text-sm font-bold">
                2
              </div>
              <CardHeader>
                <div className="w-16 h-16 bg-industrial/10 rounded-full flex items-center justify-center mb-4">
                  <Factory className="h-8 w-8 text-industrial" />
                </div>
                <CardTitle className="text-industrial">
                  Advanced Processing
                </CardTitle>
                <CardDescription>
                  State-of-the-art extrusion and forming
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-industrial" />
                    Twin-screw extruders
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-industrial" />
                    Precision forming dies
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-industrial" />
                    Automated sizing
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-industrial" />
                    Temperature control
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden">
              <div className="absolute top-4 right-4 w-8 h-8 bg-steel text-white rounded-full flex items-center justify-center text-sm font-bold">
                3
              </div>
              <CardHeader>
                <div className="w-16 h-16 bg-steel/10 rounded-full flex items-center justify-center mb-4">
                  <FlaskConical className="h-8 w-8 text-steel" />
                </div>
                <CardTitle className="text-steel">Quality Testing</CardTitle>
                <CardDescription>
                  Comprehensive testing at every stage
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-steel" />
                    Pressure testing
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-steel" />
                    Dimensional verification
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-steel" />
                    Material composition
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-steel" />
                    Performance validation
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden">
              <div className="absolute top-4 right-4 w-8 h-8 bg-steelblue text-white rounded-full flex items-center justify-center text-sm font-bold">
                4
              </div>
              <CardHeader>
                <div className="w-16 h-16 bg-steelblue/10 rounded-full flex items-center justify-center mb-4">
                  <Truck className="h-8 w-8 text-steelblue" />
                </div>
                <CardTitle className="text-steelblue">
                  Packaging & Delivery
                </CardTitle>
                <CardDescription>
                  Secure packaging and global logistics
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-steelblue" />
                    Protective packaging
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-steelblue" />
                    Custom labeling
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-steelblue" />
                    Logistics coordination
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-steelblue" />
                    Delivery tracking
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </AnimatedSection>

      {/* Production Capabilities */}
      <AnimatedSection
        as="section"
        className="py-16 lg:py-20 bg-gray-50"
        animation="fadeInUp"
      >
        <div className="container mx-auto px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-industrial/10 text-industrial">
                Production Capabilities
              </Badge>
              <h2 className="text-3xl lg:text-4xl font-bold text-industrial mb-6">
                Advanced Manufacturing Infrastructure
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Our facility spans 50,000 square meters and houses
                state-of-the-art equipment operated by skilled technicians,
                ensuring consistent quality and efficiency.
              </p>

              <div className="space-y-6">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium">PVC Production</span>
                    <span className="text-sm text-muted-foreground">
                      4,000 tons/month
                    </span>
                  </div>
                  <Progress value={80} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium">HDPE Production</span>
                    <span className="text-sm text-muted-foreground">
                      3,500 tons/month
                    </span>
                  </div>
                  <Progress value={70} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium">Steel Production</span>
                    <span className="text-sm text-muted-foreground">
                      2,500 tons/month
                    </span>
                  </div>
                  <Progress value={50} className="h-2" />
                </div>
              </div>

              <Button
                asChild
                className="mt-8 bg-industrial hover:bg-industrial-dark"
              >
                <Link to="/contact">Request Facility Tour</Link>
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <Card>
                <CardHeader className="text-center">
                  <Clock className="h-8 w-8 text-steelblue mx-auto mb-2" />
                  <CardTitle className="text-lg">24/7 Operations</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-sm text-muted-foreground">
                    Continuous production to meet demanding schedules
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="text-center">
                  <Users className="h-8 w-8 text-industrial mx-auto mb-2" />
                  <CardTitle className="text-lg">Skilled Workforce</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-sm text-muted-foreground">
                    200+ trained professionals and engineers
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="text-center">
                  <Cog className="h-8 w-8 text-steel mx-auto mb-2" />
                  <CardTitle className="text-lg">Modern Equipment</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-sm text-muted-foreground">
                    Latest European and Japanese machinery
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="text-center">
                  <TrendingUp className="h-8 w-8 text-steelblue mx-auto mb-2" />
                  <CardTitle className="text-lg">Efficiency</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-sm text-muted-foreground">
                    95% overall equipment effectiveness
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </AnimatedSection>

      {/* Quality Assurance */}
      <AnimatedSection
        as="section"
        className="py-16 lg:py-20"
        animation="fadeInUp"
      >
        <div className="container mx-auto px-8">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-steelblue/10 text-steelblue">
              Quality Assurance
            </Badge>
            <h2 className="text-3xl lg:text-4xl font-bold text-industrial mb-4">
              Rigorous Quality Control
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Every pipe undergoes comprehensive testing to ensure it meets or
              exceeds international standards and customer specifications.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <Card className="text-center">
              <CardHeader>
                <FlaskConical className="h-12 w-12 text-steelblue mx-auto mb-4" />
                <CardTitle className="text-steelblue">
                  Laboratory Testing
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Material composition analysis</li>
                  <li>• Mechanical property testing</li>
                  <li>• Chemical resistance verification</li>
                  <li>• Thermal stability assessment</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <BarChart3 className="h-12 w-12 text-industrial mx-auto mb-4" />
                <CardTitle className="text-industrial">
                  Performance Testing
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Hydrostatic pressure testing</li>
                  <li>• Ring stiffness measurement</li>
                  <li>• Impact resistance testing</li>
                  <li>• Long-term performance evaluation</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <Award className="h-12 w-12 text-steel mx-auto mb-4" />
                <CardTitle className="text-steel">Certification</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• ISO 9001:2015 certified</li>
                  <li>• Third-party inspections</li>
                  <li>• International standards compliance</li>
                  <li>• Customer-specific certifications</li>
                </ul>
              </CardContent>
            </Card>
          </div>

          <div className="bg-gradient-to-r from-steelblue/5 to-industrial/5 p-8 rounded-lg">
            <h3 className="text-2xl font-bold text-industrial text-center mb-6">
              Quality Standards We Meet
            </h3>
            <div className="grid md:grid-cols-4 gap-6 text-center">
              <div className="bg-white p-4 rounded-lg">
                <div className="font-semibold text-steelblue mb-1">
                  ISO 9001:2015
                </div>
                <div className="text-xs text-muted-foreground">
                  Quality Management
                </div>
              </div>
              <div className="bg-white p-4 rounded-lg">
                <div className="font-semibold text-steelblue mb-1">ASTM</div>
                <div className="text-xs text-muted-foreground">
                  American Standards
                </div>
              </div>
              <div className="bg-white p-4 rounded-lg">
                <div className="font-semibold text-steelblue mb-1">EN/DIN</div>
                <div className="text-xs text-muted-foreground">
                  European Standards
                </div>
              </div>
              <div className="bg-white p-4 rounded-lg">
                <div className="font-semibold text-steelblue mb-1">API 5L</div>
                <div className="text-xs text-muted-foreground">
                  Pipeline Standards
                </div>
              </div>
            </div>
          </div>
        </div>
      </AnimatedSection>

      {/* Environmental Commitment */}
      <AnimatedSection
        as="section"
        className="py-16 lg:py-20 bg-gray-50"
        animation="fadeInUp"
      >
        <div className="container mx-auto px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-steelblue/10 text-steelblue">
                Environmental Commitment
              </Badge>
              <h2 className="text-3xl lg:text-4xl font-bold text-industrial mb-6">
                Sustainable Manufacturing
              </h2>
              <p className="text-lg text-muted-foreground mb-6">
                We're committed to environmental responsibility through
                efficient processes, waste reduction, and sustainable practices
                throughout our operations.
              </p>

              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-steelblue mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-medium">Energy Efficiency</div>
                    <div className="text-sm text-muted-foreground">
                      35% reduction in energy consumption through modern
                      equipment
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-steelblue mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-medium">Waste Reduction</div>
                    <div className="text-sm text-muted-foreground">
                      95% material utilization with recycling programs
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-steelblue mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-medium">Water Conservation</div>
                    <div className="text-sm text-muted-foreground">
                      Closed-loop water systems and treatment facilities
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-steelblue mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-medium">Emissions Control</div>
                    <div className="text-sm text-muted-foreground">
                      Advanced filtration and emission monitoring systems
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-steelblue mb-2">
                  35%
                </div>
                <div className="text-sm text-muted-foreground">
                  Energy Reduction
                </div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-steelblue mb-2">
                  95%
                </div>
                <div className="text-sm text-muted-foreground">
                  Material Utilization
                </div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-steelblue mb-2">
                  50%
                </div>
                <div className="text-sm text-muted-foreground">
                  Water Savings
                </div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-steelblue mb-2">
                  Zero
                </div>
                <div className="text-sm text-muted-foreground">
                  Landfill Waste
                </div>
              </div>
            </div>
          </div>
        </div>
      </AnimatedSection>

      {/* CTA Section */}
      <AnimatedSection
        as="section"
        className="py-16 lg:py-20 bg-gradient-to-r from-industrial to-steelblue text-white"
        animation="fadeInUp"
      >
        <div className="container mx-auto px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Experience Our Manufacturing Excellence
          </h2>
          <p className="text-xl mb-8 text-blue-100 max-w-2xl mx-auto">
            Visit our facility or learn more about our capabilities. We're ready
            to discuss how our manufacturing expertise can serve your project
            needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              className="bg-white text-steelblue hover:bg-gray-100 font-semibold"
            >
              <Link to="/contact">
                Schedule Facility Tour <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="bg-white text-gray-600 border-white hover:bg-white hover:text-steelblue"
            >
              <Link to="/products">View Our Products</Link>
            </Button>
          </div>
        </div>
      </AnimatedSection>
    </div>
  );
}
