import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Globe,
  Users,
  Clock,
  Award,
  Star,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  BookOpen,
  Video,
  MapPin,
} from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";

const Index = () => {
  const [currentTeacher, setCurrentTeacher] = useState(0);

  const featuredTeachers = [
    {
      name: "Sarah Johnson",
      photo:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2Fd16cb7e1cbcf42458e4b81ce09ae5e4f?format=webp&width=800",
      languages: ["English", "French"],
      experience: "8 years",
      bio: "Specialized in business English and conversational French. Cambridge certified with a passion for interactive learning.",
      rating: 4.9,
    },
    {
      name: "Ahmed Hassan",
      photo:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
      languages: ["Arabic", "English"],
      experience: "12 years",
      bio: "Native Arabic speaker with expertise in Modern Standard Arabic and dialect variations. TESOL certified.",
      rating: 4.8,
    },
    {
      name: "Maria Rodriguez",
      photo:
        "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
      languages: ["Spanish", "Portuguese"],
      experience: "6 years",
      bio: "Dynamic teacher focused on Latin American Spanish and Brazilian Portuguese. Cultural immersion specialist.",
      rating: 4.9,
    },
  ];

  const topLanguages = [
    {
      name: "English",
      icon: "🇺🇸",
      levels: ["A1", "A2", "B1", "B2", "C1", "C2"],
      description: "Master the global language of business and communication",
      students: 250,
    },
    {
      name: "French",
      icon: "🇫🇷",
      levels: ["A1", "A2", "B1", "B2", "C1"],
      description: "Explore the language of culture, cuisine, and diplomacy",
      students: 180,
    },
    {
      name: "Arabic",
      icon: "🇸🇦",
      levels: ["A1", "A2", "B1", "B2"],
      description: "Connect with the rich heritage of the Arab world",
      students: 120,
    },
    {
      name: "Spanish",
      icon: "🇪🇸",
      levels: ["A1", "A2", "B1", "B2", "C1"],
      description:
        "Communicate with over 500 million Spanish speakers worldwide",
      students: 200,
    },
  ];

  const nextTeacher = () => {
    setCurrentTeacher((prev) => (prev + 1) % featuredTeachers.length);
  };

  const prevTeacher = () => {
    setCurrentTeacher(
      (prev) => (prev - 1 + featuredTeachers.length) % featuredTeachers.length,
    );
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="absolute inset-0">
          <div className="absolute top-10 left-10 w-20 h-20 bg-white/10 rounded-full blur-xl"></div>
          <div className="absolute top-32 right-20 w-32 h-32 bg-green-400/20 rounded-full blur-2xl"></div>
          <div className="absolute bottom-20 left-1/3 w-40 h-40 bg-blue-400/20 rounded-full blur-2xl"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6">
                Learn Any Language.
                <span className="block text-green-400">Anywhere. Anytime.</span>
              </h1>
              <p className="text-xl sm:text-2xl text-blue-100 mb-8 leading-relaxed">
                Connect cultures through language learning with experienced
                teachers, flexible schedules, and proven methods.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/start-learning">
                  <Button
                    size="lg"
                    className="bg-green-500 hover:bg-green-600 text-white font-semibold px-8 py-4 text-lg"
                  >
                    <BookOpen className="w-5 h-5 mr-2" />
                    Start Learning Today
                  </Button>
                </Link>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-gray-300 text-gray-700 hover:bg-gray-100 hover:text-gray-900 font-semibold px-8 py-4 text-lg bg-white"
                >
                  <Video className="w-5 h-5 mr-2" />
                  Watch Demo
                </Button>
              </div>
            </div>
            <div className="hidden lg:block">
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=600&h=400&fit=crop"
                  alt="Students learning languages"
                  className="rounded-2xl shadow-2xl"
                />
                <div className="absolute -bottom-6 -left-6 bg-white text-gray-900 p-4 rounded-xl shadow-lg">
                  <div className="flex items-center space-x-2">
                    <Globe className="w-6 h-6 text-blue-600" />
                    <div>
                      <p className="font-semibold">12+ Languages</p>
                      <p className="text-sm text-gray-600">
                        Available to learn
                      </p>
                    </div>
                  </div>
                </div>
                <div className="absolute -top-6 -right-6 bg-green-500 text-white p-4 rounded-xl shadow-lg">
                  <div className="flex items-center space-x-2">
                    <Users className="w-6 h-6" />
                    <div>
                      <p className="font-semibold">500+ Students</p>
                      <p className="text-sm">Learning with us</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
              Why Choose LinguaBridge Academy?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We provide the perfect blend of expert instruction, flexible
              learning, and proven results to help you master any language.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center p-8 hover:shadow-lg transition-shadow duration-300">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Award className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">
                  Expert Teachers
                </h3>
                <p className="text-gray-600">
                  Certified native speakers and language experts with years of
                  teaching experience.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-8 hover:shadow-lg transition-shadow duration-300">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Clock className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">
                  Flexible Hours
                </h3>
                <p className="text-gray-600">
                  Learn at your own pace with flexible scheduling that fits your
                  busy lifestyle.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-8 hover:shadow-lg transition-shadow duration-300">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Video className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">
                  Online & In-Person
                </h3>
                <p className="text-gray-600">
                  Choose between online convenience or traditional classroom
                  learning experiences.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-8 hover:shadow-lg transition-shadow duration-300">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Globe className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">
                  Cultural Immersion
                </h3>
                <p className="text-gray-600">
                  Learn not just the language, but also the culture and customs
                  of different countries.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Top Languages Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
              Most Popular Languages
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover our most sought-after language courses designed to help
              you communicate with confidence worldwide.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {topLanguages.map((language, index) => (
              <Card
                key={index}
                className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-2 cursor-pointer"
              >
                <CardContent className="p-8">
                  <div className="text-center">
                    <div className="text-6xl mb-4">{language.icon}</div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-4">
                      {language.name}
                    </h3>
                    <p className="text-gray-600 mb-6">{language.description}</p>

                    <div className="space-y-4">
                      <div>
                        <p className="text-sm text-gray-500 mb-2">
                          Available Levels:
                        </p>
                        <div className="flex flex-wrap gap-2 justify-center">
                          {language.levels.map((level) => (
                            <span
                              key={level}
                              className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded"
                            >
                              {level}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center justify-center space-x-2 text-sm text-gray-600">
                        <Users className="w-4 h-4" />
                        <span>{language.students} students enrolled</span>
                      </div>
                    </div>

                    <Link
                      to={`/teachers?language=${encodeURIComponent(language.name)}`}
                    >
                      <Button className="w-full mt-6 group-hover:bg-blue-600 transition-colors duration-300">
                        See Teachers
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link to="/languages">
              <Button variant="outline" size="lg" className="font-semibold">
                View All Languages
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Teachers Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
              Meet Our Featured Teachers
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Learn from experienced professionals who are passionate about
              helping you achieve your language learning goals.
            </p>
          </div>

          <div className="relative">
            <Card className="max-w-4xl mx-auto">
              <CardContent className="p-12">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                  <div className="text-center lg:text-left">
                    <img
                      src={featuredTeachers[currentTeacher].photo}
                      alt={featuredTeachers[currentTeacher].name}
                      className="w-64 h-64 rounded-full object-cover mx-auto lg:mx-0 mb-8 shadow-lg"
                    />
                  </div>

                  <div>
                    <div className="flex items-center mb-4">
                      <div className="flex text-yellow-400">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-5 h-5 ${
                              i <
                              Math.floor(
                                featuredTeachers[currentTeacher].rating,
                              )
                                ? "fill-current"
                                : ""
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-gray-600 ml-2">
                        {featuredTeachers[currentTeacher].rating}
                      </span>
                    </div>

                    <h3 className="text-3xl font-bold text-gray-900 mb-2">
                      {featuredTeachers[currentTeacher].name}
                    </h3>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {featuredTeachers[currentTeacher].languages.map(
                        (lang) => (
                          <span
                            key={lang}
                            className="bg-blue-100 text-blue-800 font-medium px-3 py-1 rounded-full"
                          >
                            {lang}
                          </span>
                        ),
                      )}
                    </div>

                    <p className="text-gray-600 mb-4">
                      <strong>Experience:</strong>{" "}
                      {featuredTeachers[currentTeacher].experience}
                    </p>

                    <p className="text-gray-700 mb-8 leading-relaxed">
                      {featuredTeachers[currentTeacher].bio}
                    </p>

                    <Link
                      to={`/start-learning?teacher=${encodeURIComponent(featuredTeachers[currentTeacher].name)}`}
                    >
                      <Button
                        size="lg"
                        className="bg-green-500 hover:bg-green-600"
                      >
                        Book Trial Lesson
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Navigation Buttons */}
            <button
              onClick={prevTeacher}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white shadow-lg rounded-full p-3 hover:bg-gray-50 transition-colors duration-200"
            >
              <ChevronLeft className="w-6 h-6 text-gray-600" />
            </button>

            <button
              onClick={nextTeacher}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white shadow-lg rounded-full p-3 hover:bg-gray-50 transition-colors duration-200"
            >
              <ChevronRight className="w-6 h-6 text-gray-600" />
            </button>

            {/* Dots Indicator */}
            <div className="flex justify-center mt-8 space-x-2">
              {featuredTeachers.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentTeacher(index)}
                  className={`w-3 h-3 rounded-full transition-colors duration-200 ${
                    index === currentTeacher ? "bg-blue-600" : "bg-gray-300"
                  }`}
                />
              ))}
            </div>
          </div>

          <div className="text-center mt-12">
            <Link to="/teachers">
              <Button variant="outline" size="lg" className="font-semibold">
                View All Teachers
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Contact CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl sm:text-4xl font-bold mb-6">
              Ready to Start Your Language Journey?
            </h2>
            <p className="text-xl text-blue-100 mb-8 leading-relaxed">
              Join hundreds of students who have transformed their communication
              skills with LinguaBridge Academy. Start learning today and open
              doors to new opportunities worldwide.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
              <div className="bg-white/10 rounded-lg p-6">
                <MapPin className="w-8 h-8 mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Visit Us</h3>
                <p className="text-blue-100">Oran, Algeria</p>
              </div>
              <div className="bg-white/10 rounded-lg p-6">
                <Users className="w-8 h-8 mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Call Us</h3>
                <p className="text-blue-100">+213 557 921 145</p>
              </div>
              <div className="bg-white/10 rounded-lg p-6">
                <Globe className="w-8 h-8 mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Learn Online</h3>
                <p className="text-blue-100">Anywhere, Anytime</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/contact">
                <Button
                  size="lg"
                  className="bg-green-500 hover:bg-green-600 text-white font-semibold px-8 py-4 text-lg"
                >
                  Contact Us Today
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Link to="/start-learning">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-gray-300 text-gray-700 hover:text-blue-600 hover:border-blue-600 hover:bg-white font-semibold px-8 py-4 text-lg bg-white"
                >
                  Schedule Free Trial
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
