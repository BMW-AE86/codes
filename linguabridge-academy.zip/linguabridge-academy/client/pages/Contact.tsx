import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Mail,
  Phone,
  MapPin,
  Clock,
  Globe,
  Users,
  Send,
  MessageCircle,
  Calendar,
  CheckCircle,
} from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    language: "",
    message: "",
    preferredContact: "",
    lessonType: "",
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would typically send the form data to your backend
    console.log("Form submitted:", formData);
    setIsSubmitted(true);
    // Reset form after 3 seconds
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({
        name: "",
        email: "",
        phone: "",
        language: "",
        message: "",
        preferredContact: "",
        lessonType: "",
      });
    }, 3000);
  };

  const languages = [
    "English",
    "French",
    "Arabic",
    "Spanish",
    "German",
    "Italian",
    "Mandarin Chinese",
    "Japanese",
    "Other",
  ];

  const contactMethods = [
    {
      icon: <Phone className="w-6 h-6" />,
      title: "Call Us",
      info: "+213 557 921 145",
      description: "Mon-Sat: 9AM-6PM (Algeria Time)",
      color: "bg-blue-500",
    },
    {
      icon: <Mail className="w-6 h-6" />,
      title: "Email Us",
      info: "info@linguabridge.academy",
      description: "We'll respond within 24 hours",
      color: "bg-green-500",
    },
    {
      icon: <MapPin className="w-6 h-6" />,
      title: "Visit Us",
      info: "Oran, Algeria",
      description: "In-person consultations available",
      color: "bg-purple-500",
    },
    {
      icon: <MessageCircle className="w-6 h-6" />,
      title: "Live Chat",
      info: "Available Now",
      description: "Quick questions and support",
      color: "bg-orange-500",
    },
  ];

  const faqItems = [
    {
      question: "How do I book a trial lesson?",
      answer:
        "Simply fill out our contact form and select 'Free Trial Lesson' as your lesson type. We'll contact you within 24 hours to schedule your session.",
    },
    {
      question: "What languages do you offer?",
      answer:
        "We offer 8+ languages including English, French, Arabic, Spanish, German, Italian, Mandarin Chinese, and Japanese. Contact us for other language requests.",
    },
    {
      question: "Do you offer online classes?",
      answer:
        "Yes! We offer both online and in-person classes. Online classes are conducted via video conferencing with interactive materials.",
    },
    {
      question: "What are your class schedules?",
      answer:
        "We offer flexible scheduling including evenings and weekends. Classes can be scheduled based on your availability and teacher's schedule.",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-6">
              Get In Touch
            </h1>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Ready to start your language learning journey? Contact us today
              and let's discuss how we can help you achieve your goals.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <div className="bg-white/10 rounded-lg p-4">
                <Users className="w-8 h-8 mx-auto mb-2" />
                <p className="font-semibold">Expert Support</p>
                <p className="text-sm text-blue-200">Personalized guidance</p>
              </div>
              <div className="bg-white/10 rounded-lg p-4">
                <Clock className="w-8 h-8 mx-auto mb-2" />
                <p className="font-semibold">Quick Response</p>
                <p className="text-sm text-blue-200">Within 24 hours</p>
              </div>
              <div className="bg-white/10 rounded-lg p-4">
                <Globe className="w-8 h-8 mx-auto mb-2" />
                <p className="font-semibold">Free Consultation</p>
                <p className="text-sm text-blue-200">No obligation</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Methods */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Multiple Ways to Reach Us
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Choose the contact method that works best for you. We're here to
              help and answer any questions about our language programs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {contactMethods.map((method, index) => (
              <Card
                key={index}
                className="text-center hover:shadow-lg transition-shadow duration-300"
              >
                <CardContent className="pt-8 pb-6">
                  <div
                    className={`w-16 h-16 ${method.color} rounded-full flex items-center justify-center mx-auto mb-4 text-white`}
                  >
                    {method.icon}
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {method.title}
                  </h3>
                  <p className="text-blue-600 font-medium mb-2">
                    {method.info}
                  </p>
                  <p className="text-sm text-gray-600">{method.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form and Map Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="shadow-xl">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-gray-900">
                  Send Us a Message
                </CardTitle>
                <p className="text-gray-600">
                  Fill out the form below and we'll get back to you as soon as
                  possible.
                </p>
              </CardHeader>
              <CardContent>
                {isSubmitted ? (
                  <div className="text-center py-12">
                    <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      Message Sent Successfully!
                    </h3>
                    <p className="text-gray-600">
                      Thank you for contacting us. We'll get back to you within
                      24 hours.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">Full Name *</Label>
                        <Input
                          id="name"
                          type="text"
                          required
                          value={formData.name}
                          onChange={(e) =>
                            handleInputChange("name", e.target.value)
                          }
                          placeholder="Enter your full name"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">Email Address *</Label>
                        <Input
                          id="email"
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) =>
                            handleInputChange("email", e.target.value)
                          }
                          placeholder="your.email@example.com"
                          className="mt-1"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) =>
                          handleInputChange("phone", e.target.value)
                        }
                        placeholder="+213 XXX XXX XXX"
                        className="mt-1"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="language">Language of Interest</Label>
                        <Select
                          value={formData.language}
                          onValueChange={(value) =>
                            handleInputChange("language", value)
                          }
                        >
                          <SelectTrigger className="mt-1">
                            <SelectValue placeholder="Select a language" />
                          </SelectTrigger>
                          <SelectContent>
                            {languages.map((language) => (
                              <SelectItem key={language} value={language}>
                                {language}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="lessonType">Lesson Type</Label>
                        <Select
                          value={formData.lessonType}
                          onValueChange={(value) =>
                            handleInputChange("lessonType", value)
                          }
                        >
                          <SelectTrigger className="mt-1">
                            <SelectValue placeholder="Select lesson type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="trial">
                              Free Trial Lesson
                            </SelectItem>
                            <SelectItem value="individual">
                              Individual Lessons
                            </SelectItem>
                            <SelectItem value="group">Group Classes</SelectItem>
                            <SelectItem value="intensive">
                              Intensive Course
                            </SelectItem>
                            <SelectItem value="business">
                              Business Language
                            </SelectItem>
                            <SelectItem value="exam">
                              Exam Preparation
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="preferredContact">
                        Preferred Contact Method
                      </Label>
                      <Select
                        value={formData.preferredContact}
                        onValueChange={(value) =>
                          handleInputChange("preferredContact", value)
                        }
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="How should we contact you?" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="email">Email</SelectItem>
                          <SelectItem value="phone">Phone Call</SelectItem>
                          <SelectItem value="whatsapp">WhatsApp</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="message">Message *</Label>
                      <Textarea
                        id="message"
                        required
                        value={formData.message}
                        onChange={(e) =>
                          handleInputChange("message", e.target.value)
                        }
                        placeholder="Tell us about your language learning goals, current level, or any questions you have..."
                        rows={5}
                        className="mt-1"
                      />
                    </div>

                    <Button
                      type="submit"
                      size="lg"
                      className="w-full bg-blue-600 hover:bg-blue-700"
                    >
                      <Send className="w-5 h-5 mr-2" />
                      Send Message
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>

            {/* Map and Location Info */}
            <div className="space-y-8">
              {/* Location Card */}
              <Card className="shadow-xl">
                <CardHeader>
                  <CardTitle className="text-2xl font-bold text-gray-900">
                    Visit Our Location
                  </CardTitle>
                  <p className="text-gray-600">
                    We're located in the heart of Oran, Algeria. Drop by for a
                    consultation or to meet our teachers.
                  </p>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <MapPin className="w-6 h-6 text-red-500 mt-1" />
                      <div>
                        <p className="font-semibold text-gray-900">Address</p>
                        <p className="text-gray-600">
                          LinguaBridge Academy
                          <br />
                          Oran, Algeria
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <Phone className="w-6 h-6 text-blue-500 mt-1" />
                      <div>
                        <p className="font-semibold text-gray-900">Phone</p>
                        <p className="text-gray-600">+213 557 921 145</p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <Clock className="w-6 h-6 text-green-500 mt-1" />
                      <div>
                        <p className="font-semibold text-gray-900">
                          Office Hours
                        </p>
                        <div className="text-gray-600">
                          <p>Monday - Friday: 9:00 AM - 6:00 PM</p>
                          <p>Saturday: 10:00 AM - 4:00 PM</p>
                          <p>Sunday: Closed</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <Mail className="w-6 h-6 text-purple-500 mt-1" />
                      <div>
                        <p className="font-semibold text-gray-900">Email</p>
                        <p className="text-gray-600">
                          info@linguabridge.academy
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Map */}
              <Card className="shadow-xl">
                <CardContent className="p-0">
                  <div className="w-full h-80 bg-gray-200 rounded-lg overflow-hidden">
                    <iframe
                      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d105073.84478572847!2d-0.8284990442089844!3d35.70388030000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd7e8a6e75bbbc1d%3A0x7142c8e70b5b3a92!2sOran%2C%20Algeria!5e0!3m2!1sen!2sus!4v1677689234567!5m2!1sen!2sus"
                      width="100%"
                      height="100%"
                      style={{ border: 0 }}
                      allowFullScreen
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                      title="LinguaBridge Academy Location - Oran, Algeria"
                    ></iframe>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-lg text-gray-600">
              Quick answers to common questions about our language programs.
            </p>
          </div>

          <div className="space-y-6">
            {faqItems.map((item, index) => (
              <Card
                key={index}
                className="shadow-sm hover:shadow-md transition-shadow duration-200"
              >
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">
                    {item.question}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">{item.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-700 text-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">
            Ready to Start Your Language Journey?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Don't wait any longer. Contact us today and take the first step
            towards mastering a new language.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/start-learning">
              <Button size="lg" className="bg-green-500 hover:bg-green-600">
                <Calendar className="w-5 h-5 mr-2" />
                Book Free Trial Lesson
              </Button>
            </Link>
            <Button
              size="lg"
              variant="outline"
              className="border-gray-300 text-gray-700 hover:text-blue-600 hover:border-blue-600 hover:bg-white bg-white"
            >
              <Phone className="w-5 h-5 mr-2" />
              Call Now: +213 557 921 145
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
