import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Star,
  Users,
  Clock,
  Award,
  Search,
  Filter,
  Globe,
  Video,
  MapPin,
  Mail,
  Calendar,
  BookOpen,
} from "lucide-react";
import { useState, useEffect } from "react";
import { useSearchParams, Link } from "react-router-dom";

const Teachers = () => {
  const [searchParams] = useSearchParams();
  const [selectedLanguage, setSelectedLanguage] = useState(
    searchParams.get("language") || "All",
  );
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const languageParam = searchParams.get("language");
    if (languageParam) {
      setSelectedLanguage(languageParam);
    }
  }, [searchParams]);

  const teachers = [
    {
      id: 1,
      name: "Sarah Johnson",
      photo:
        "https://cdn.builder.io/api/v1/image/assets%2Ff437020d2595432692b5e23d56de6c22%2Fd16cb7e1cbcf42458e4b81ce09ae5e4f?format=webp&width=800",
      languages: ["English", "French"],
      specialization: "Business English & Conversational French",
      experience: 8,
      rating: 4.9,
      students: 156,
      bio: "Cambridge certified teacher with expertise in business communication and conversational French. Specializes in interactive learning methods and cultural immersion techniques.",
      education: "MA in Applied Linguistics, Cambridge University",
      certifications: [
        "CELTA",
        "DELF/DALF Examiner",
        "Business English Certificate",
      ],
      hourlyRate: "$35",
      availability: "Mon-Fri: 9AM-6PM",
      modes: ["Online", "In-Person"],
      lessonTypes: ["Individual", "Group", "Intensive"],
      achievements: [
        "5+ years Cambridge exam preparation",
        "95% student pass rate",
        "Corporate training specialist",
      ],
    },
    {
      id: 2,
      name: "Ahmed Hassan",
      photo:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
      languages: ["Arabic", "English"],
      specialization: "Modern Standard Arabic & Regional Dialects",
      experience: 12,
      rating: 4.8,
      students: 203,
      bio: "Native Arabic speaker with deep knowledge of MSA and various regional dialects. Experienced in teaching Arabic to international students and diplomats.",
      education: "PhD in Arabic Literature, University of Cairo",
      certifications: ["TESOL", "Arabic Language Teaching Certificate"],
      hourlyRate: "$40",
      availability: "Mon-Sat: 10AM-8PM",
      modes: ["Online", "In-Person"],
      lessonTypes: ["Individual", "Group"],
      achievements: [
        "Taught diplomats and embassy staff",
        "12+ years experience",
        "Cultural integration specialist",
      ],
    },
    {
      id: 3,
      name: "Maria Rodriguez",
      photo:
        "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
      languages: ["Spanish", "Portuguese"],
      specialization: "Latin American Spanish & Brazilian Portuguese",
      experience: 6,
      rating: 4.9,
      students: 142,
      bio: "Dynamic teacher from Colombia with extensive experience in Latin American Spanish and Brazilian Portuguese. Focuses on practical communication and cultural understanding.",
      education: "BA in Modern Languages, Universidad Nacional de Colombia",
      certifications: ["DELE Examiner", "CELPE-Bras Certificate"],
      hourlyRate: "$30",
      availability: "Mon-Fri: 8AM-5PM",
      modes: ["Online", "In-Person"],
      lessonTypes: ["Individual", "Group", "Conversation"],
      achievements: [
        "Cultural immersion specialist",
        "Travel Spanish expert",
        "85+ satisfied students",
      ],
    },
    {
      id: 4,
      name: "Pierre Dubois",
      photo:
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
      languages: ["French", "English"],
      specialization: "French Literature & Academic French",
      experience: 10,
      rating: 4.7,
      students: 98,
      bio: "Parisian teacher with a passion for French literature and academic writing. Specializes in advanced French courses and university preparation.",
      education: "MA in French Literature, Université de la Sorbonne",
      certifications: ["DELF/DALF Examiner", "FLE Certificate"],
      hourlyRate: "$38",
      availability: "Tue-Sat: 2PM-9PM",
      modes: ["Online", "In-Person"],
      lessonTypes: ["Individual", "Academic"],
      achievements: [
        "University preparation specialist",
        "Literature and culture expert",
        "Academic writing focus",
      ],
    },
    {
      id: 5,
      name: "Hans Mueller",
      photo:
        "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop&crop=face",
      languages: ["German", "English"],
      specialization: "Business German & Technical Vocabulary",
      experience: 9,
      rating: 4.6,
      students: 87,
      bio: "German engineer turned language teacher. Specializes in business German and technical vocabulary for professionals in engineering and manufacturing.",
      education: "MS in Engineering, Technical University of Munich",
      certifications: [
        "Goethe Institute Certificate",
        "Business German Teaching",
      ],
      hourlyRate: "$42",
      availability: "Mon-Thu: 6PM-10PM, Sat: 9AM-3PM",
      modes: ["Online", "In-Person"],
      lessonTypes: ["Individual", "Business", "Technical"],
      achievements: [
        "Technical German specialist",
        "Corporate client base",
        "Engineering background",
      ],
    },
    {
      id: 6,
      name: "Giuseppe Romano",
      photo:
        "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop&crop=face",
      languages: ["Italian", "English"],
      specialization: "Italian Culture & Conversational Italian",
      experience: 7,
      rating: 4.8,
      students: 76,
      bio: "Passionate Italian teacher from Rome. Combines language learning with Italian culture, art, and cuisine for an immersive learning experience.",
      education: "BA in Italian Studies, Università di Roma",
      certifications: ["CILS Examiner", "Italian Culture Certificate"],
      hourlyRate: "$32",
      availability: "Mon-Fri: 3PM-8PM",
      modes: ["Online", "In-Person"],
      lessonTypes: ["Individual", "Group", "Cultural"],
      achievements: [
        "Cultural immersion expert",
        "Art and cuisine integration",
        "Conversation specialist",
      ],
    },
    {
      id: 7,
      name: "Li Wei",
      photo:
        "https://images.unsplash.com/photo-1507591064344-4c6ce005b128?w=400&h=400&fit=crop&crop=face",
      languages: ["Mandarin Chinese", "English"],
      specialization: "Business Chinese & HSK Preparation",
      experience: 8,
      rating: 4.9,
      students: 134,
      bio: "Native Mandarin speaker with extensive business background. Specializes in HSK exam preparation and business Chinese for international professionals.",
      education: "MBA, Peking University",
      certifications: ["HSK Examiner", "Business Chinese Teaching Certificate"],
      hourlyRate: "$36",
      availability: "Mon-Sat: 7AM-2PM",
      modes: ["Online", "In-Person"],
      lessonTypes: ["Individual", "Business", "HSK Prep"],
      achievements: [
        "HSK exam specialist",
        "Business Chinese expert",
        "MBA background",
      ],
    },
    {
      id: 8,
      name: "Yuki Tanaka",
      photo:
        "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face",
      languages: ["Japanese", "English"],
      specialization: "JLPT Preparation & Japanese Business Culture",
      experience: 6,
      rating: 4.7,
      students: 89,
      bio: "Tokyo native with expertise in JLPT preparation and Japanese business culture. Makes learning Japanese engaging through pop culture and modern context.",
      education: "BA in International Studies, Waseda University",
      certifications: ["JLPT Examiner", "Japanese Teaching Certificate"],
      hourlyRate: "$34",
      availability: "Mon-Fri: 6PM-11PM (JST)",
      modes: ["Online", "In-Person"],
      lessonTypes: ["Individual", "Group", "JLPT Prep"],
      achievements: [
        "JLPT preparation expert",
        "Business culture specialist",
        "Pop culture integration",
      ],
    },
  ];

  const languages = [
    "All",
    "English",
    "French",
    "Arabic",
    "Spanish",
    "German",
    "Italian",
    "Mandarin Chinese",
    "Japanese",
  ];

  const filteredTeachers = teachers.filter((teacher) => {
    const matchesLanguage =
      selectedLanguage === "All" ||
      teacher.languages.includes(selectedLanguage);
    const matchesSearch =
      searchTerm === "" ||
      teacher.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      teacher.specialization.toLowerCase().includes(searchTerm.toLowerCase()) ||
      teacher.languages.some((lang) =>
        lang.toLowerCase().includes(searchTerm.toLowerCase()),
      );
    return matchesLanguage && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-6">
              Meet Our Expert Teachers
            </h1>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Learn from certified native speakers and experienced professionals
              who are passionate about helping you achieve your language
              learning goals.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <div className="bg-white/10 rounded-lg p-4">
                <Users className="w-8 h-8 mx-auto mb-2" />
                <p className="font-semibold">{teachers.length} Teachers</p>
                <p className="text-sm text-blue-200">Expert Instructors</p>
              </div>
              <div className="bg-white/10 rounded-lg p-4">
                <Globe className="w-8 h-8 mx-auto mb-2" />
                <p className="font-semibold">8+ Languages</p>
                <p className="text-sm text-blue-200">Available</p>
              </div>
              <div className="bg-white/10 rounded-lg p-4">
                <Star className="w-8 h-8 mx-auto mb-2" />
                <p className="font-semibold">4.8 Average</p>
                <p className="text-sm text-blue-200">Rating</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Filters Section */}
      <section className="py-8 bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-6 items-center">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                type="text"
                placeholder="Search teachers..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            {/* Language Filter */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-gray-600" />
                <span className="font-medium text-gray-700">Filter by:</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {languages.map((language) => (
                  <Button
                    key={language}
                    variant={
                      selectedLanguage === language ? "default" : "outline"
                    }
                    size="sm"
                    onClick={() => setSelectedLanguage(language)}
                    className={
                      selectedLanguage === language
                        ? "bg-blue-600 hover:bg-blue-700"
                        : ""
                    }
                  >
                    {language}
                  </Button>
                ))}
              </div>
            </div>
          </div>

          {/* Results Count */}
          <div className="mt-4">
            <p className="text-gray-600">
              Showing {filteredTeachers.length} teacher
              {filteredTeachers.length !== 1 ? "s" : ""}
              {selectedLanguage !== "All" && ` for ${selectedLanguage}`}
            </p>
          </div>
        </div>
      </section>

      {/* Teachers Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {filteredTeachers.length === 0 ? (
            <div className="text-center py-16">
              <Users className="w-16 h-16 mx-auto text-gray-400 mb-4" />
              <h3 className="text-2xl font-semibold text-gray-900 mb-2">
                No teachers found
              </h3>
              <p className="text-gray-600 mb-6">
                Try adjusting your search or filter criteria.
              </p>
              <Button
                onClick={() => {
                  setSelectedLanguage("All");
                  setSearchTerm("");
                }}
              >
                Reset Filters
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {filteredTeachers.map((teacher) => (
                <Card
                  key={teacher.id}
                  className="overflow-hidden hover:shadow-xl transition-all duration-300"
                >
                  <CardContent className="p-6">
                    <div className="flex flex-col sm:flex-row gap-6">
                      {/* Teacher Photo */}
                      <div className="flex-shrink-0">
                        <img
                          src={teacher.photo}
                          alt={teacher.name}
                          className="w-32 h-32 rounded-full object-cover mx-auto sm:mx-0"
                        />
                      </div>

                      {/* Teacher Info */}
                      <div className="flex-1 space-y-4">
                        {/* Header */}
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="text-xl font-bold text-gray-900">
                              {teacher.name}
                            </h3>
                            <div className="flex items-center space-x-1">
                              <Star className="w-4 h-4 fill-current text-yellow-400" />
                              <span className="font-medium">
                                {teacher.rating}
                              </span>
                            </div>
                          </div>
                          <p className="text-blue-600 font-medium">
                            {teacher.specialization}
                          </p>
                        </div>

                        {/* Languages */}
                        <div>
                          <p className="text-sm text-gray-600 mb-2">
                            Languages:
                          </p>
                          <div className="flex flex-wrap gap-2">
                            {teacher.languages.map((language) => (
                              <Badge
                                key={language}
                                className="bg-blue-100 text-blue-800"
                              >
                                {language}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        {/* Stats */}
                        <div className="grid grid-cols-3 gap-4 text-center">
                          <div>
                            <Clock className="w-5 h-5 mx-auto mb-1 text-gray-600" />
                            <p className="font-semibold text-gray-900">
                              {teacher.experience}
                            </p>
                            <p className="text-xs text-gray-600">Years Exp.</p>
                          </div>
                          <div>
                            <Users className="w-5 h-5 mx-auto mb-1 text-gray-600" />
                            <p className="font-semibold text-gray-900">
                              {teacher.students}
                            </p>
                            <p className="text-xs text-gray-600">Students</p>
                          </div>
                          <div>
                            <Award className="w-5 h-5 mx-auto mb-1 text-gray-600" />
                            <p className="font-semibold text-gray-900">
                              {teacher.hourlyRate}
                            </p>
                            <p className="text-xs text-gray-600">Per Hour</p>
                          </div>
                        </div>

                        {/* Bio */}
                        <p className="text-gray-700 text-sm leading-relaxed">
                          {teacher.bio}
                        </p>

                        {/* Certifications */}
                        <div>
                          <p className="text-sm font-medium text-gray-900 mb-2">
                            Certifications:
                          </p>
                          <div className="flex flex-wrap gap-1">
                            {teacher.certifications.map((cert, idx) => (
                              <Badge
                                key={idx}
                                variant="outline"
                                className="text-xs"
                              >
                                {cert}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        {/* Learning Modes */}
                        <div>
                          <p className="text-sm font-medium text-gray-900 mb-2">
                            Available:
                          </p>
                          <div className="flex gap-2">
                            {teacher.modes.map((mode) => (
                              <Badge
                                key={mode}
                                variant="outline"
                                className="flex items-center gap-1"
                              >
                                {mode === "Online" ? (
                                  <Video className="w-3 h-3" />
                                ) : (
                                  <MapPin className="w-3 h-3" />
                                )}
                                {mode}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex flex-col sm:flex-row gap-3 pt-4">
                          <Link
                            to={`/start-learning?teacher=${encodeURIComponent(teacher.name)}`}
                            className="flex-1"
                          >
                            <Button className="w-full">
                              <Calendar className="w-4 h-4 mr-2" />
                              Book Trial Lesson
                            </Button>
                          </Link>
                          <Link to="/contact" className="flex-1">
                            <Button variant="outline" className="w-full">
                              <Mail className="w-4 h-4 mr-2" />
                              Contact Teacher
                            </Button>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-700 text-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Start Learning?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Connect with the perfect teacher for your language learning journey.
            Book a trial lesson today and take the first step towards fluency.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/contact">
              <Button
                size="lg"
                className="bg-gray-500 text-white hover:bg-blue-600 hover:border-blue-600"
              >
                <BookOpen className="w-5 h-5 mr-2" />
                Schedule Free Trial
              </Button>
            </Link>
            <Link to="/languages">
              <Button
                size="lg"
                variant="outline"
                className="border-gray-300 text-gray-700 hover:text-blue-600 hover:border-blue-600 hover:bg-white bg-white"
              >
                <Globe className="w-5 h-5 mr-2" />
                View All Languages
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Teachers;
