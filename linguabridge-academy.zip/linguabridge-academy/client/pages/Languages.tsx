import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Globe,
  Users,
  Clock,
  BookOpen,
  Video,
  MapPin,
  Star,
  CheckCircle,
} from "lucide-react";
import { Link } from "react-router-dom";

const Languages = () => {
  const languages = [
    {
      name: "English",
      flag: "🇺🇸",
      category: "Germanic Language",
      description:
        "Master the global language of business, technology, and international communication. Our comprehensive English program covers everything from basic conversation to advanced business communication.",
      levels: [
        { code: "A1", name: "Beginner", duration: "3 months", price: "$120" },
        { code: "A2", name: "Elementary", duration: "3 months", price: "$140" },
        {
          code: "B1",
          name: "Intermediate",
          duration: "4 months",
          price: "$160",
        },
        {
          code: "B2",
          name: "Upper-Intermediate",
          duration: "4 months",
          price: "$180",
        },
        { code: "C1", name: "Advanced", duration: "5 months", price: "$200" },
        {
          code: "C2",
          name: "Proficiency",
          duration: "6 months",
          price: "$220",
        },
      ],
      features: [
        "Business English specialization",
        "IELTS/TOEFL preparation",
        "Conversation practice sessions",
        "Grammar and writing workshops",
      ],
      modes: ["Online", "In-Person"],
      students: 250,
      teachers: 8,
      popularity: "Most Popular",
      color: "bg-blue-500",
    },
    {
      name: "French",
      flag: "🇫🇷",
      category: "Romance Language",
      description:
        "Explore the language of culture, cuisine, and diplomacy. Learn French through immersive cultural experiences and interactive conversation practice with native speakers.",
      levels: [
        { code: "A1", name: "Beginner", duration: "3 months", price: "$130" },
        { code: "A2", name: "Elementary", duration: "3 months", price: "$150" },
        {
          code: "B1",
          name: "Intermediate",
          duration: "4 months",
          price: "$170",
        },
        {
          code: "B2",
          name: "Upper-Intermediate",
          duration: "4 months",
          price: "$190",
        },
        { code: "C1", name: "Advanced", duration: "5 months", price: "$210" },
      ],
      features: [
        "French culture immersion",
        "DELF/DALF preparation",
        "Literature and art discussion",
        "Pronunciation workshops",
      ],
      modes: ["Online", "In-Person"],
      students: 180,
      teachers: 5,
      popularity: "Trending",
      color: "bg-indigo-500",
    },
    {
      name: "Arabic",
      flag: "🇸🇦",
      category: "Semitic Language",
      description:
        "Connect with the rich heritage of the Arab world and unlock opportunities in the Middle East. Learn Modern Standard Arabic and regional dialects from native speakers.",
      levels: [
        { code: "A1", name: "Beginner", duration: "4 months", price: "$140" },
        { code: "A2", name: "Elementary", duration: "4 months", price: "$160" },
        {
          code: "B1",
          name: "Intermediate",
          duration: "5 months",
          price: "$180",
        },
        {
          code: "B2",
          name: "Upper-Intermediate",
          duration: "5 months",
          price: "$200",
        },
      ],
      features: [
        "Modern Standard Arabic (MSA)",
        "Regional dialect options",
        "Arabic calligraphy classes",
        "Islamic culture studies",
      ],
      modes: ["Online", "In-Person"],
      students: 120,
      teachers: 4,
      popularity: "Growing Fast",
      color: "bg-emerald-500",
    },
    {
      name: "Spanish",
      flag: "🇪🇸",
      category: "Romance Language",
      description:
        "Communicate with over 500 million Spanish speakers worldwide. Learn both European and Latin American Spanish variants through engaging cultural content.",
      levels: [
        { code: "A1", name: "Beginner", duration: "3 months", price: "$125" },
        { code: "A2", name: "Elementary", duration: "3 months", price: "$145" },
        {
          code: "B1",
          name: "Intermediate",
          duration: "4 months",
          price: "$165",
        },
        {
          code: "B2",
          name: "Upper-Intermediate",
          duration: "4 months",
          price: "$185",
        },
        { code: "C1", name: "Advanced", duration: "5 months", price: "$205" },
      ],
      features: [
        "European & Latin American variants",
        "DELE exam preparation",
        "Spanish cinema and music",
        "Travel Spanish specialization",
      ],
      modes: ["Online", "In-Person"],
      students: 200,
      teachers: 6,
      popularity: "High Demand",
      color: "bg-red-500",
    },
    {
      name: "German",
      flag: "🇩🇪",
      category: "Germanic Language",
      description:
        "Master the language of innovation and engineering. Perfect for business, academics, and career advancement in German-speaking countries.",
      levels: [
        { code: "A1", name: "Beginner", duration: "4 months", price: "$135" },
        { code: "A2", name: "Elementary", duration: "4 months", price: "$155" },
        {
          code: "B1",
          name: "Intermediate",
          duration: "5 months",
          price: "$175",
        },
        {
          code: "B2",
          name: "Upper-Intermediate",
          duration: "5 months",
          price: "$195",
        },
      ],
      features: [
        "Business German focus",
        "Goethe Institute preparation",
        "Technical vocabulary",
        "German culture workshops",
      ],
      modes: ["Online", "In-Person"],
      students: 95,
      teachers: 3,
      popularity: "Professional Choice",
      color: "bg-yellow-600",
    },
    {
      name: "Italian",
      flag: "🇮🇹",
      category: "Romance Language",
      description:
        "Discover the melodious language of art, fashion, and cuisine. Learn Italian through cultural immersion and creative expression.",
      levels: [
        { code: "A1", name: "Beginner", duration: "3 months", price: "$130" },
        { code: "A2", name: "Elementary", duration: "3 months", price: "$150" },
        {
          code: "B1",
          name: "Intermediate",
          duration: "4 months",
          price: "$170",
        },
        {
          code: "B2",
          name: "Upper-Intermediate",
          duration: "4 months",
          price: "$190",
        },
      ],
      features: [
        "Art and culture focus",
        "Culinary Italian vocabulary",
        "Opera and music appreciation",
        "Regional dialect exposure",
      ],
      modes: ["Online", "In-Person"],
      students: 75,
      teachers: 3,
      popularity: "Cultural Favorite",
      color: "bg-green-600",
    },
    {
      name: "Mandarin Chinese",
      flag: "🇨🇳",
      category: "Sino-Tibetan Language",
      description:
        "Learn the world's most spoken language and unlock opportunities in the fastest-growing economy. Master both simplified and traditional characters.",
      levels: [
        { code: "A1", name: "Beginner", duration: "5 months", price: "$150" },
        { code: "A2", name: "Elementary", duration: "5 months", price: "$170" },
        {
          code: "B1",
          name: "Intermediate",
          duration: "6 months",
          price: "$190",
        },
        {
          code: "B2",
          name: "Upper-Intermediate",
          duration: "6 months",
          price: "$210",
        },
      ],
      features: [
        "Simplified & Traditional characters",
        "HSK exam preparation",
        "Business Chinese focus",
        "Calligraphy workshops",
      ],
      modes: ["Online", "In-Person"],
      students: 85,
      teachers: 4,
      popularity: "Future-Focused",
      color: "bg-red-600",
    },
    {
      name: "Japanese",
      flag: "🇯🇵",
      category: "Japonic Language",
      description:
        "Enter the fascinating world of Japanese language and culture. Learn Hiragana, Katakana, and Kanji through innovative teaching methods.",
      levels: [
        { code: "A1", name: "Beginner", duration: "5 months", price: "$145" },
        { code: "A2", name: "Elementary", duration: "5 months", price: "$165" },
        {
          code: "B1",
          name: "Intermediate",
          duration: "6 months",
          price: "$185",
        },
        {
          code: "B2",
          name: "Upper-Intermediate",
          duration: "6 months",
          price: "$205",
        },
      ],
      features: [
        "Three writing systems mastery",
        "JLPT exam preparation",
        "Anime and manga culture",
        "Business Japanese (Keigo)",
      ],
      modes: ["Online", "In-Person"],
      students: 110,
      teachers: 3,
      popularity: "Pop Culture Hit",
      color: "bg-pink-500",
    },
  ];

  const getPopularityColor = (popularity: string) => {
    switch (popularity) {
      case "Most Popular":
        return "bg-blue-100 text-blue-800";
      case "Trending":
        return "bg-purple-100 text-purple-800";
      case "Growing Fast":
        return "bg-green-100 text-green-800";
      case "High Demand":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-6">
              Languages We Offer
            </h1>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Choose from our comprehensive selection of language courses
              designed to help you communicate confidently in a globalized
              world.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <div className="bg-white/10 rounded-lg p-4">
                <Globe className="w-8 h-8 mx-auto mb-2" />
                <p className="font-semibold">8+ Languages</p>
                <p className="text-sm text-blue-200">Available</p>
              </div>
              <div className="bg-white/10 rounded-lg p-4">
                <Users className="w-8 h-8 mx-auto mb-2" />
                <p className="font-semibold">1000+ Students</p>
                <p className="text-sm text-blue-200">Learning</p>
              </div>
              <div className="bg-white/10 rounded-lg p-4">
                <Star className="w-8 h-8 mx-auto mb-2" />
                <p className="font-semibold">Expert Teachers</p>
                <p className="text-sm text-blue-200">Native Speakers</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Languages Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {languages.map((language, index) => (
              <Card
                key={index}
                className="overflow-hidden hover:shadow-xl transition-all duration-300"
              >
                <CardContent className="p-0">
                  {/* Language Header */}
                  <div className={`${language.color} text-white p-6`}>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-4">
                        <span className="text-4xl">{language.flag}</span>
                        <div>
                          <h3 className="text-2xl font-bold">
                            {language.name}
                          </h3>
                          <p className="text-white/80">{language.category}</p>
                        </div>
                      </div>
                      <Badge
                        className={getPopularityColor(language.popularity)}
                      >
                        {language.popularity}
                      </Badge>
                    </div>
                    <p className="text-white/90">{language.description}</p>
                  </div>

                  <div className="p-6">
                    {/* Stats */}
                    <div className="grid grid-cols-3 gap-4 mb-6">
                      <div className="text-center">
                        <Users className="w-6 h-6 mx-auto mb-2 text-gray-600" />
                        <p className="font-semibold text-gray-900">
                          {language.students}
                        </p>
                        <p className="text-sm text-gray-600">Students</p>
                      </div>
                      <div className="text-center">
                        <BookOpen className="w-6 h-6 mx-auto mb-2 text-gray-600" />
                        <p className="font-semibold text-gray-900">
                          {language.teachers}
                        </p>
                        <p className="text-sm text-gray-600">Teachers</p>
                      </div>
                      <div className="text-center">
                        <Clock className="w-6 h-6 mx-auto mb-2 text-gray-600" />
                        <p className="font-semibold text-gray-900">
                          {language.levels.length}
                        </p>
                        <p className="text-sm text-gray-600">Levels</p>
                      </div>
                    </div>

                    {/* Learning Modes */}
                    <div className="mb-6">
                      <h4 className="font-semibold text-gray-900 mb-3">
                        Learning Modes:
                      </h4>
                      <div className="flex gap-2">
                        {language.modes.map((mode) => (
                          <Badge
                            key={mode}
                            variant="outline"
                            className="flex items-center gap-1"
                          >
                            {mode === "Online" ? (
                              <Video className="w-3 h-3" />
                            ) : (
                              <MapPin className="w-3 h-3" />
                            )}
                            {mode}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* Features */}
                    <div className="mb-6">
                      <h4 className="font-semibold text-gray-900 mb-3">
                        Course Features:
                      </h4>
                      <div className="grid grid-cols-1 gap-2">
                        {language.features.map((feature, idx) => (
                          <div
                            key={idx}
                            className="flex items-center space-x-2"
                          >
                            <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                            <span className="text-gray-700 text-sm">
                              {feature}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Levels */}
                    <div className="mb-6">
                      <h4 className="font-semibold text-gray-900 mb-3">
                        Available Levels:
                      </h4>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {language.levels.map((level) => (
                          <div
                            key={level.code}
                            className="bg-gray-50 p-3 rounded-lg text-center"
                          >
                            <p className="font-semibold text-gray-900">
                              {level.code}
                            </p>
                            <p className="text-xs text-gray-600">
                              {level.name}
                            </p>
                            <p className="text-xs text-gray-500">
                              {level.duration}
                            </p>
                            <p className="text-sm font-medium text-blue-600">
                              {level.price}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex flex-col sm:flex-row gap-3">
                      <Link
                        to={`/teachers?language=${encodeURIComponent(language.name)}`}
                        className="flex-1"
                      >
                        <Button className="w-full">
                          <Users className="w-4 h-4 mr-2" />
                          See Teachers
                        </Button>
                      </Link>
                      <Link to="/contact" className="flex-1">
                        <Button variant="outline" className="w-full">
                          <BookOpen className="w-4 h-4 mr-2" />
                          Enroll Now
                        </Button>
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-700 text-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Can't Find Your Language?</h2>
          <p className="text-xl text-blue-100 mb-8">
            We're always expanding our language offerings. Contact us to inquire
            about additional languages or request a custom language program.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/contact">
              <Button size="lg" className="bg-green-500 hover:bg-green-600">
                Request New Language
              </Button>
            </Link>
            <Link to="/teachers">
              <Button
                size="lg"
                variant="outline"
                className="border-gray-300 text-gray-700 hover:text-blue-600 hover:border-blue-600 hover:bg-white bg-white"
              >
                Browse All Teachers
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Languages;
