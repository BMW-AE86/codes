import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Calendar,
  Clock,
  Globe,
  Users,
  Video,
  MapPin,
  Gift,
  CheckCircle,
  Star,
  BookOpen,
  Award,
  Phone,
  Mail,
  ArrowRight,
} from "lucide-react";
import { useState } from "react";
import { useSearchParams } from "react-router-dom";

const StartLearning = () => {
  const [searchParams] = useSearchParams();
  const preselectedLanguage = searchParams.get("language") || "";
  const preselectedTeacher = searchParams.get("teacher") || "";

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    language: preselectedLanguage,
    currentLevel: "",
    preferredTeacher: preselectedTeacher,
    lessonMode: "",
    preferredTime: "",
    preferredDays: [] as string[],
    goals: "",
    experience: "",
    agreeToTerms: false,
    subscribeNewsletter: false,
  });

  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (
    field: string,
    value: string | boolean | string[],
  ) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleDayToggle = (day: string) => {
    setFormData((prev) => ({
      ...prev,
      preferredDays: prev.preferredDays.includes(day)
        ? prev.preferredDays.filter((d) => d !== day)
        : [...prev.preferredDays, day],
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Trial lesson booking:", formData);
    setIsSubmitted(true);
  };

  const nextStep = () => setCurrentStep((prev) => Math.min(prev + 1, 3));
  const prevStep = () => setCurrentStep((prev) => Math.max(prev - 1, 1));

  const languages = [
    "English",
    "French",
    "Arabic",
    "Spanish",
    "German",
    "Italian",
    "Mandarin Chinese",
    "Japanese",
  ];

  const teachers = [
    "Sarah Johnson (English/French)",
    "Ahmed Hassan (Arabic/English)",
    "Maria Rodriguez (Spanish/Portuguese)",
    "Pierre Dubois (French/English)",
    "Hans Mueller (German/English)",
    "Giuseppe Romano (Italian/English)",
    "Li Wei (Mandarin Chinese/English)",
    "Yuki Tanaka (Japanese/English)",
  ];

  const levels = [
    "Complete Beginner (A0)",
    "Beginner (A1)",
    "Elementary (A2)",
    "Intermediate (B1)",
    "Upper-Intermediate (B2)",
    "Advanced (C1)",
    "Proficiency (C2)",
    "Not Sure",
  ];

  const timeSlots = [
    "Morning (9:00 AM - 12:00 PM)",
    "Afternoon (12:00 PM - 5:00 PM)",
    "Evening (5:00 PM - 8:00 PM)",
    "Night (8:00 PM - 10:00 PM)",
  ];

  const days = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
  ];

  const benefits = [
    {
      icon: <Gift className="w-8 h-8" />,
      title: "100% Free Trial",
      description:
        "No hidden costs or commitments. Just pure learning experience.",
      color: "bg-green-500",
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Expert Teacher",
      description:
        "Learn from certified native speakers and experienced professionals.",
      color: "bg-blue-500",
    },
    {
      icon: <Clock className="w-8 h-8" />,
      title: "45-Minute Session",
      description:
        "Full lesson experience with personalized assessment and feedback.",
      color: "bg-purple-500",
    },
    {
      icon: <BookOpen className="w-8 h-8" />,
      title: "Custom Learning Plan",
      description:
        "Receive a tailored roadmap based on your goals and current level.",
      color: "bg-orange-500",
    },
  ];

  const steps = [
    {
      number: 1,
      title: "Personal Info",
      description: "Tell us about yourself",
    },
    {
      number: 2,
      title: "Learning Preferences",
      description: "Choose your ideal setup",
    },
    {
      number: 3,
      title: "Schedule & Goals",
      description: "Plan your learning journey",
    },
  ];

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 flex items-center justify-center">
        <Card className="max-w-2xl mx-auto shadow-2xl">
          <CardContent className="text-center py-16 px-8">
            <div className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-8">
              <CheckCircle className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              🎉 Congratulations!
            </h1>
            <h2 className="text-xl font-semibold text-gray-800 mb-6">
              Your Free Trial Lesson is Booked!
            </h2>
            <p className="text-gray-600 mb-8 leading-relaxed">
              We've received your booking request for a free trial lesson in{" "}
              <strong>{formData.language}</strong>. Our team will contact you
              within 24 hours to confirm your lesson time and provide joining
              instructions.
            </p>

            <div className="bg-blue-50 rounded-lg p-6 mb-8">
              <h3 className="font-semibold text-gray-900 mb-4">
                What happens next?
              </h3>
              <div className="space-y-3 text-left">
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                    1
                  </div>
                  <p className="text-gray-700">
                    We'll call you within 24 hours to confirm your lesson
                  </p>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                    2
                  </div>
                  <p className="text-gray-700">
                    Receive joining instructions and learning materials
                  </p>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                    3
                  </div>
                  <p className="text-gray-700">
                    Enjoy your 45-minute free trial lesson!
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="bg-gray-50 rounded-lg p-4">
                <Phone className="w-6 h-6 text-blue-500 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Questions?</p>
                <p className="font-semibold">+213 557 921 145</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <Mail className="w-6 h-6 text-green-500 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Email us</p>
                <p className="font-semibold text-xs">
                  info@linguabridge.academy
                </p>
              </div>
            </div>

            <Button
              size="lg"
              className="bg-blue-600 hover:bg-blue-700"
              onClick={() => (window.location.href = "/")}
            >
              Return to Homepage
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-6">
              Start Your Language Journey Today
            </h1>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Book your completely free 45-minute trial lesson with one of our
              expert teachers. No commitments, no hidden costs - just pure
              learning!
            </p>

            {/* Benefits */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
              {benefits.map((benefit, index) => (
                <div
                  key={index}
                  className="bg-white/10 rounded-lg p-6 text-center"
                >
                  <div
                    className={`w-16 h-16 ${benefit.color} rounded-full flex items-center justify-center mx-auto mb-4 text-white`}
                  >
                    {benefit.icon}
                  </div>
                  <h3 className="font-semibold mb-2">{benefit.title}</h3>
                  <p className="text-sm text-blue-200">{benefit.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Booking Form */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Progress Steps */}
          <div className="mb-12">
            <div className="flex justify-center">
              <div className="flex items-center space-x-8">
                {steps.map((step, index) => (
                  <div key={index} className="flex items-center">
                    <div className="text-center">
                      <div
                        className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg ${
                          currentStep >= step.number
                            ? "bg-blue-600 text-white"
                            : "bg-gray-200 text-gray-600"
                        }`}
                      >
                        {currentStep > step.number ? (
                          <CheckCircle className="w-6 h-6" />
                        ) : (
                          step.number
                        )}
                      </div>
                      <p className="text-sm font-medium text-gray-700 mt-2">
                        {step.title}
                      </p>
                      <p className="text-xs text-gray-500">
                        {step.description}
                      </p>
                    </div>
                    {index < steps.length - 1 && (
                      <div
                        className={`w-16 h-1 mx-4 ${
                          currentStep > step.number
                            ? "bg-blue-600"
                            : "bg-gray-200"
                        }`}
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-center">
                Book Your Free Trial Lesson
              </CardTitle>
              <p className="text-center text-gray-600">
                Step {currentStep} of 3 - {steps[currentStep - 1].description}
              </p>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit}>
                {/* Step 1: Personal Information */}
                {currentStep === 1 && (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="firstName">First Name *</Label>
                        <Input
                          id="firstName"
                          required
                          value={formData.firstName}
                          onChange={(e) =>
                            handleInputChange("firstName", e.target.value)
                          }
                          placeholder="Enter your first name"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="lastName">Last Name *</Label>
                        <Input
                          id="lastName"
                          required
                          value={formData.lastName}
                          onChange={(e) =>
                            handleInputChange("lastName", e.target.value)
                          }
                          placeholder="Enter your last name"
                          className="mt-1"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) =>
                          handleInputChange("email", e.target.value)
                        }
                        placeholder="your.email@example.com"
                        className="mt-1"
                      />
                    </div>

                    <div>
                      <Label htmlFor="phone">Phone Number *</Label>
                      <Input
                        id="phone"
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) =>
                          handleInputChange("phone", e.target.value)
                        }
                        placeholder="+213 XXX XXX XXX"
                        className="mt-1"
                      />
                    </div>

                    <div>
                      <Label htmlFor="language">
                        Language You Want to Learn *
                      </Label>
                      <Select
                        value={formData.language}
                        onValueChange={(value) =>
                          handleInputChange("language", value)
                        }
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Select a language" />
                        </SelectTrigger>
                        <SelectContent>
                          {languages.map((language) => (
                            <SelectItem key={language} value={language}>
                              {language}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="currentLevel">Current Level</Label>
                      <Select
                        value={formData.currentLevel}
                        onValueChange={(value) =>
                          handleInputChange("currentLevel", value)
                        }
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Select your current level" />
                        </SelectTrigger>
                        <SelectContent>
                          {levels.map((level) => (
                            <SelectItem key={level} value={level}>
                              {level}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Step 2: Learning Preferences */}
                {currentStep === 2 && (
                  <div className="space-y-6">
                    <div>
                      <Label htmlFor="preferredTeacher">
                        Preferred Teacher (Optional)
                      </Label>
                      <Select
                        value={formData.preferredTeacher}
                        onValueChange={(value) =>
                          handleInputChange("preferredTeacher", value)
                        }
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Any available teacher" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="any">
                            Any available teacher
                          </SelectItem>
                          {teachers.map((teacher) => (
                            <SelectItem key={teacher} value={teacher}>
                              {teacher}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Lesson Mode *</Label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-2">
                        <Card
                          className={`cursor-pointer transition-all ${
                            formData.lessonMode === "online"
                              ? "ring-2 ring-blue-500 bg-blue-50"
                              : "hover:shadow-md"
                          }`}
                          onClick={() =>
                            handleInputChange("lessonMode", "online")
                          }
                        >
                          <CardContent className="p-4 text-center">
                            <Video className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                            <h3 className="font-semibold">Online Lesson</h3>
                            <p className="text-sm text-gray-600">
                              Learn from anywhere via video call
                            </p>
                          </CardContent>
                        </Card>
                        <Card
                          className={`cursor-pointer transition-all ${
                            formData.lessonMode === "inperson"
                              ? "ring-2 ring-blue-500 bg-blue-50"
                              : "hover:shadow-md"
                          }`}
                          onClick={() =>
                            handleInputChange("lessonMode", "inperson")
                          }
                        >
                          <CardContent className="p-4 text-center">
                            <MapPin className="w-8 h-8 mx-auto mb-2 text-green-600" />
                            <h3 className="font-semibold">In-Person Lesson</h3>
                            <p className="text-sm text-gray-600">
                              Visit our location in Oran
                            </p>
                          </CardContent>
                        </Card>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="preferredTime">Preferred Time Slot</Label>
                      <Select
                        value={formData.preferredTime}
                        onValueChange={(value) =>
                          handleInputChange("preferredTime", value)
                        }
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Select preferred time" />
                        </SelectTrigger>
                        <SelectContent>
                          {timeSlots.map((slot) => (
                            <SelectItem key={slot} value={slot}>
                              {slot}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>
                        Preferred Days (Select all that work for you)
                      </Label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2">
                        {days.map((day) => (
                          <div
                            key={day}
                            className="flex items-center space-x-2"
                          >
                            <Checkbox
                              id={day}
                              checked={formData.preferredDays.includes(day)}
                              onCheckedChange={() => handleDayToggle(day)}
                            />
                            <Label htmlFor={day} className="text-sm">
                              {day}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Step 3: Goals and Experience */}
                {currentStep === 3 && (
                  <div className="space-y-6">
                    <div>
                      <Label htmlFor="goals">Learning Goals *</Label>
                      <Textarea
                        id="goals"
                        required
                        value={formData.goals}
                        onChange={(e) =>
                          handleInputChange("goals", e.target.value)
                        }
                        placeholder="What do you want to achieve? (e.g., business communication, travel, exams, personal interest...)"
                        rows={4}
                        className="mt-1"
                      />
                    </div>

                    <div>
                      <Label htmlFor="experience">
                        Previous Learning Experience
                      </Label>
                      <Textarea
                        id="experience"
                        value={formData.experience}
                        onChange={(e) =>
                          handleInputChange("experience", e.target.value)
                        }
                        placeholder="Tell us about any previous experience with this language or language learning in general..."
                        rows={3}
                        className="mt-1"
                      />
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="terms"
                          checked={formData.agreeToTerms}
                          onCheckedChange={(checked) =>
                            handleInputChange("agreeToTerms", checked)
                          }
                        />
                        <Label htmlFor="terms" className="text-sm">
                          I agree to the terms and conditions and privacy policy
                          *
                        </Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="newsletter"
                          checked={formData.subscribeNewsletter}
                          onCheckedChange={(checked) =>
                            handleInputChange("subscribeNewsletter", checked)
                          }
                        />
                        <Label htmlFor="newsletter" className="text-sm">
                          I would like to receive updates about new courses and
                          special offers
                        </Label>
                      </div>
                    </div>
                  </div>
                )}

                {/* Navigation Buttons */}
                <div className="flex justify-between mt-8">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={prevStep}
                    disabled={currentStep === 1}
                    className={currentStep === 1 ? "invisible" : ""}
                  >
                    Previous
                  </Button>

                  {currentStep < 3 ? (
                    <Button
                      type="button"
                      onClick={nextStep}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      Next Step
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  ) : (
                    <Button
                      type="submit"
                      disabled={!formData.agreeToTerms}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Calendar className="w-4 h-4 mr-2" />
                      Book My Free Trial
                    </Button>
                  )}
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Students Choose LinguaBridge Academy
            </h2>
            <p className="text-lg text-gray-600">
              Join thousands of satisfied students who have transformed their
              language skills with us.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardContent className="pt-8 pb-6">
                <Star className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-3">4.9/5 Rating</h3>
                <p className="text-gray-600">
                  Average student satisfaction rating across all courses
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-8 pb-6">
                <Award className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-3">
                  Certified Teachers
                </h3>
                <p className="text-gray-600">
                  All our instructors are certified and experienced
                  professionals
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-8 pb-6">
                <Users className="w-12 h-12 text-green-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-3">1000+ Students</h3>
                <p className="text-gray-600">
                  Successfully helped students achieve their language goals
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default StartLearning;
